/* Code de votre application */
const k = kernelite;