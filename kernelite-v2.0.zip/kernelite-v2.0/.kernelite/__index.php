<?php

function kRoot() { global $kAppRoot; return $kAppRoot; }

# Check .kernelite requirement
include($kAppRoot.".kernelite".$ds."__requirement.php");

# Kernelite/Start
global $Kernelite; # $Kernelite must live
require($kAppRoot.".kernelite".$ds."__initKernel.php");
Events::emit('kernelite.beforeStart');
$Kernelite = new Kernelite();

if( PHPCLI ) {
    # Daemon Execution
    $daemon = new Daemon( $argv );
}
else {
    Events::emit('kernelite.endInitialisation', $Kernelite);
    $Kernelite->processQuery( $Kernelite->queryParameters );
}

exit;
?>