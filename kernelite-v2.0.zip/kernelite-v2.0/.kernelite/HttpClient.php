<?php

class HttpClient {

    private $method = "GET";
    private $methodList = ["HEAD","GET","POST","PUT","UPDATE","DELETE","INSERT"];
    private $postDatas = [];
    private $headers = [];
    private $url = "";
    private $connexionTimeout = 30;
    private $curlTimeout = 30;
    private $httpCode = null;

    private $curl = null;
    private $exec = null;
    private $errMessage = null;

    private $isJsonResponseValid = null;
    private $jsonResponse = null;

    public function __construct( Array $args = [] ) {
        $this->headers = [
            "Cache-Control: no-cache",
            "content-type:application/json;charset=utf-8"
        ];
        return $this;
    }
    public function setMethod( String $method ) {
        $method = strtoupper($method);
        if( !in_array($method,$this->methodList) )
            err("La méthode $method n'est pas autorisée");
        $this->method = $method;
    }
    public function setURL( String $url ) {
        if( !filter_var($url, FILTER_VALIDATE_URL) )
            err("L'URL fournie n'est pas valide : $url");
        $this->url = $url;
    }    
    public function setPostDatas( Array $datas ) {
        foreach($datas as $k=>$e)
            $this->postDatas[$k] = $e;
    }
    public function getPostDatas() {
        return  $this->postDatas;
    }
    public function addFile( String $key, String $file ) {
        if( !file_exists($file) ) 
            err("Fichier introuvable");
        $this->postDatas[$key] = curl_file_create($file);
    }
    public function setHeaders( Array $headers ) {
        $this->headers = [];
        foreach($headers as $header)
            $this->headers[] = $header;
    }
    public function setConnectTimeout( Int $seconds ) {
        $this->connexionTimeout = $seconds;
    }
    public function setCurlTimeout( Int $seconds ) {
        $this->curlTimeout = $seconds;
    }    
    public function execute() {
        if( !filter_var($this->url, FILTER_VALIDATE_URL) )
            err("Veuillez préciser une URL (HttpClient->setURL)");

        $this->curl = curl_init($this->url);
        curl_setopt($this->curl, CURLOPT_RETURNTRANSFER, true); 
        //curl_setopt($this->curl, CURLOPT_HEADER, true);
        curl_setopt($this->curl, CURLOPT_CONNECTTIMEOUT, $this->connexionTimeout);
        curl_setopt($this->curl, CURLOPT_TIMEOUT, $this->curlTimeout);
        curl_setopt($this->curl, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($this->curl, CURLOPT_SSL_VERIFYPEER, false );
        curl_setopt($this->curl, CURLOPT_SSL_VERIFYHOST, false );


        if( $this->method == "POST" ) {
            curl_setopt($this->curl, CURLOPT_POST, true);
        }
        if( !in_array($this->method,["GET","PUT"]) )
            curl_setopt($this->curl, CURLOPT_CUSTOMREQUEST, $this->method); 
        if( !empty($this->postDatas) )
            curl_setopt($this->curl, CURLOPT_POSTFIELDS, $this->postDatas);

        $this->exec = curl_exec($this->curl);
        if (curl_errno($this->curl) ) {
            $this->errMessage = curl_error($this->curl);
            return false;
        }

        $this->httpCode = curl_getinfo($this->curl, CURLINFO_HTTP_CODE);
        if( $this->httpCode !== intval(200) ) {
            $this->errMessage = "L'appel a retourné un code ".$this->httpCode;
            return false;
        }

        curl_close($this->curl);   

        if( json_validate($this->exec) ) {
            $this->isJsonResponseValid = true;
            $this->jsonResponse = json_decode($this->exec, TRUE);     
        }
        else $this->isJsonResponseValid = false;

        return true;
    }

    public function isValidResponse() {
        return $this->isJsonResponseValid === TRUE;
    }
    public function response() {
        return $this->jsonResponse ?? $this->exec;
    }
    public function rawResponse() {
        return $this->exec;
    }
    public function getError() {
        return $this->errMessage;
    }

}