<div class="container text-center mt-5">
    <img src="{% asset(css/vendor/images/kernelite-logo-m.png) %}" height="300"/>
    <div class="alert alert-success mt-3">
        <i class="far fa-check-circle mb-3" style="font-size:50px"></i>
        <br/>
        .kernelite v<?php echo KVERS;?> est installé et configuré.<br/>
        <strong>Vous pouvez démarrer votre projet</strong>
    </div>
    <a class="btn btn-success mt-3" href="http://intranet.snew.fr/kernelite/" target="_blank">.documentation <i class="fas fa-external-link-alt"></i></a>
    <a class="btn btn-info mt-3" href="{% route(test) %}">Page de test</a>
</div>