<div id="kernelite-loader-template" style="display: none">
    <div class="kernelite-loader">
        <div class="kernelite-loader-background"></div>
        <div class="kernelite-loader-engine">
			<div class="lds-roller">
				<div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div>
				<span>Veuillez patienter...</span>
			</div>
        </div>
    </div>
</div>