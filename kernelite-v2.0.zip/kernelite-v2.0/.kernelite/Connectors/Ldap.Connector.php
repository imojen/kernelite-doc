<?php

class Ldap {

    private $session;
    private $bind;
    private $user;
    private $credentials;

    public function __construct() {
        $this->isLdapEnabled();
        $this->getConfCredentials();
        $this->createSession();
    }
    private function isLdapEnabled() {
        if( !function_exists('ldap_connect') )
            err("Le module LDAP n'est pas activé sur le système");
    }
    private function getConfCredentials() {
        $security = Logger::getSecurity();
        if( empty($security) || !isset($security['ldap']) )
            err("[Ldap] La confifuration du LDAP n'est pas présente dans le fichier security.yaml");
        foreach( $security['ldap'] as $k=>$e )
            if( trim($e) == "" )
                err("[Ldap] Tous les champs sont obligatoires pour l'authentifacation au LDAP");
        $this->credentials = $security['ldap'];
    }
    private function createSession() {
        try {
            $this->session = ldap_connect($this->credentials['host'],$this->credentials['port']);
            if( $this->credentials['protocol_version'] != "" )
                ldap_set_option($this->session, LDAP_OPT_PROTOCOL_VERSION, intval($this->credentials['protocol_version']) );
            if( $this->credentials['referrals'] != "" )
                ldap_set_option($this->session, LDAP_OPT_REFERRALS, $this->credentials['referrals']);
        }
        catch( Exception $e ) {
            err("[Ldap] ".$e->getMessage());
        }
    }
    public function authenticate( String $login, String $password ) {
        $this->user = $login."@".$this->credentials['domain'];

        k_doNotThrowError(true);
        $this->bind = @ldap_bind($this->session, $this->user, $password);
        if( !$this->bind ) return false;
        k_doNotThrowError(false);

        try {
            $search = ldap_search($this->session, $this->credentials['root'],'sAMAccountName='.$login);
            if( $search && !empty($search) ) {
                $entries = ldap_get_entries($this->session, $search);
                if( !empty($entries) ) {
                $raw = array_pop($entries);
                $response = [];
                foreach( $raw as $k=>$e ) {
                    $response[$k] = mb_convert_encoding($e[0] ?? $e,'UTF-8');
                }
                $this->close();
                return $response;
                }
            }
            $this->close();
            return false;
        }
        catch( Exception $e ) {
            $this->close();
            err("[Ldap] ".$e->getMessage());
        }
        return false;
    }

    public function close() {
        ldap_close($this->session);
    }



}