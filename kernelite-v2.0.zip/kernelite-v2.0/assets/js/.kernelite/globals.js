if( !klog ) {
    let kerneliteConsoleStyle = "color:blue; background : #D6F3FF";
    function klog( item = undefined, stacktrace = false )  {
        console.log('%cKernelite Log - Type : %s', kerneliteConsoleStyle, typeof item)
        console.log('%c%o', kerneliteConsoleStyle, item)
        if(stacktrace)
            console.trace("%cKernelite StackTrace", kerneliteConsoleStyle)
    }
}
if( !knotice ) {
    let kNoticeStyle = [
        'color: #E65100',
        'background-color:#FFF3E0',
        'font-size: 15px',
        'line-height: 15px',
        'padding: 5px',
        'margin : 0px'
    ]
    function knotice( str = undefined ) {
        if( typeof str != "string" && typeof str != "int" ) return klog(str);
        let stack = new Error().stack.split("\n"),
            callStack = [];
        stack.forEach( el => { 
            try {
                let v = el?.trim().split(' ')[1]
                if( !kernelite.isNull(v) ) callStack.push(v)
            } catch( e ) {}
        })
        console.log(`%c⚠️ Notice :\n${str}\n\n${callStack.reverse().join(' ⮚ ')} `, kNoticeStyle.join(';'))
    }
}
