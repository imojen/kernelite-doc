<?php

class FormValidator {

    private Array $structure;
    private Array $datas;
    private String $name;
    private Bool $updateMode;

    private Array $errors;
    private Bool $state;

    public function __construct( String $name, Array $datas, Bool $updateMode = false ) {
        $this->name = $name;
        $this->structure = s($name);
        $this->datas = $datas;
        $this->errors = [];
        $this->state = true;
        $this->updateMode = $updateMode;

        if( empty($this->datas) )
            core::apiError("Aucune données n'a été recue");

        $this->proceedValidation();
    }

    private function addError( $str ) {
        $this->errors[] = $str;
        $this->state = false;
        return $this;
    }

    public function getErrors() {
        return $this->errors;
    }
    public function getStatus() {
        return $this->state;
    }

    private function proceedValidation() {
        global $Kernelite;

        foreach( $this->structure as $field => $p ) {
            if( isset($p['hide']) && $p['hide'] == true ) continue;
            if( !isset($p['check']) || $p['check'] == false ) continue;
            if( !isset($this->datas[$field]) ) {
                if( !$this->updateMode )
                    $this->addError("Le champ ".($p['label']??$field)." est obligatoire");
                continue;
            }
            $value = $this->datas[$field];
            $name = $p['label'] ?? $field;

            if( !$this->updateMode && ( isset($p['unique']) && $p['unique'] == true) ) {
                $Kernelite->dm->findAll($this->name,[
                    "filter" => [
                        $field => $value
                    ]
                ]);
                if( $Kernelite->dm->count() > 0 ) {
                    $this->addError("$value existe déjà");
                    continue;                    
                }
            }

            switch( $p['check'] ) {
                case 'length' : {
                    if( !core::minMaxLength($value, $p['min'], $p['max'] ) ) {
                        $this->addError("$name doit contenir entre ".$p['min']." et ". $p['max']." caractères");
                    }
                    break;
                }
                case 'int' : {
                    if( $value != intval($value) || $value < 1 ) 
                    $this->addError("$name doit avoir une valeur");
                    break;
                }
                case 'mail' : {
                    if( !filter_var($value, FILTER_VALIDATE_EMAIL) ) {
                        $this->addError("$name doit être une adresse mail valide");
                    }
                    break;
                }
                case 'phone' : {
                    if(strlen(preg_replace('/[^0-9]/', '', $value)) != 10) {
                        $this->addError("$name doit être un numéro de téléphone valide");
                    }
                    break;
                }
                case 'password' : {
                    $r = $p['rules'];
                    if( isset($r['min'],$r['max']) ) {
                        if( !core::minMaxLength($value, $r['min'], $r['max'] ) ) {  
                            $this->addError("$name doit contenir entre ".$r['min']." et ". $r['max']." caractères");
                        }
                    }
                    if( isset($r['alphaNum']) && $r['alphaNum'] == true ) {
                        if( !ctype_alnum($value) ) {
                            $this->addError("$name doit contenir au moins un chiffre");

                        }
                    } 
                    if( isset($r['strong']) && $r['strong'] == true ) {
                        $uppercase = preg_match('@[A-Z]@', $value);
                        $lowercase = preg_match('@[a-z]@', $value);
                        $number    = preg_match('@[0-9]@', $value);
                        $specialChars = preg_match('@[^\w]@', $value);
                        if(!$uppercase || !$lowercase || !$number || !$specialChars ) {
                            $this->addError("Le mot de passe doit contenir : minuscule, majuscule, chiffre, caractère spécial");
                        }
                    }                      
                    break;
                }
                case 'confirm' : {
                    if( isset($this->datas[ $p['match'] ]) && $value !== $this->datas[ $p['match'] ] ) {
                        $this->addError($name." échouée");
                    }
                    break;
                }
            }
        }
    }



}