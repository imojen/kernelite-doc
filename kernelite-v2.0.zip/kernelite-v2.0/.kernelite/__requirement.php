<?php

global $GLOBAL_PARMS;
define('PHPCLI',php_sapi_name() == "cli");
define('APP_ROOT', kRoot() );
define('DS', DIRECTORY_SEPARATOR);

if( !function_exists('path') ) {
    function path( String $path ) {
        return str_replace(["/","\\"], DIRECTORY_SEPARATOR ,$path);
    }
}
function crashError($msg = "Error") {
    $msg = "<em>.conf/project.yaml</em><br/>".$msg;
    if( PHPCLI ) kCLICrashError($msg);
	else include(kRoot().".kernelite".DS."templates".DS."_crashError.php");
	exit;
}
function kCLICrashError( $errorMessage ) {
    if(!PHPCLI) return;
    $brs = ['<br/>','<br>','<br />'];
    $dump = [""];
    $dump[] = "\033[93m=====[.kernlite CLI ERROR]=====";
    $dump[] = "\033[31m".$errorMessage;
    $dump[] = "";
    $dump[] = "\033[93mDétails de l'erreur :\033[36m";
    ob_start();
    if( !class_exists('KernelError') )
        require(kRoot().".kernelite".DS."KernelError.php");
    KernelError::printDebugTrace();
    $content = ob_get_contents();
    $content = str_replace($brs,"\r\n", $content);
    ob_end_clean();
    $dump[] = strip_tags($content);
    $dump[] = "\033[93m=====[.kernlite Fin du message ERROR]=====\r\n\r\n";
    $dump = str_replace($brs,"\r\n", implode("\r\n",$dump))."\033[39m";
    die( $dump );    
}

# PHP VERSION CHECK
$v = floatval(phpversion());
if( $v < 7.4 ) {
    $msg = 'Votre version de PHP ('.$v.') 
    est inferieure à la version 7.4 minimale requise pour .kernelite<br/>
    Veuillez upgrader votre version de PHP';
    crashError($msg);
}


# Check config
$myProjectFile = kRoot().".conf".$ds."project.yaml";
if( !file_exists($myProjectFile) ) 
    crashError("Configuration introuvable : $myProjectFile");  
require_once(kRoot().".kernelite".$ds."Spyc.php");
try {
    $GLOBAL_CONF = Spyc::YAMLLoad( $myProjectFile );
} catch( Exception $e ) {
    crashError($e->getMessage() );
}

if( !isset($GLOBAL_CONF['conf']) )
    crashError("La clé primaire du fichier de configuration doit être <strong>conf</strong> "); 
$GLOBAL_PARMS = $GLOBAL_CONF['conf'];


$mandatory = [
    "project" => ["title","public_url","environnement"],
];
foreach( $mandatory as $key => $fields ) {
    if( !isset($GLOBAL_PARMS[$key]) )
        crashError("La clé <strong>$key</strong> est obligatoire");
    foreach( $fields as $f )
        if( !isset($GLOBAL_PARMS[$key][$f]) ||$GLOBAL_PARMS[$key][$f] == "" )
            crashError("La clé <strong>$f</strong> est obligatoire dans <strong>$key</strong>");
}
if( !filter_var($GLOBAL_PARMS[$key]['public_url'], FILTER_VALIDATE_URL) || $GLOBAL_PARMS[$key]['public_url'] == "http://..." ) {
    $kurl = (isset($_SERVER['SERVER_NAME']) ? "http".( isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 's' : '')."://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'] : '' );
    $GLOBAL_PARMS[$key]['public_url'] = $kurl;
    //crashError("La clé <strong>public_url</strong> doit être l'URL pointant à la racine du projet<br/>Par exemple : $kurl");
}
$purl = str_split($GLOBAL_PARMS[$key]['public_url']);
if( $purl[count($purl) - 1]  != "/")
    $GLOBAL_PARMS[$key]['public_url'] .= "/";
/* Base */
$kdb = $GLOBAL_PARMS['databases'] ?? null;
if( isset($kdb) && is_array($kdb) && !empty($kdb) )  {
    /* Vérification des bases */
    $bfields = ["name","mode","host","user","base"];
    $errBaseFields = [];
    $errBaseFieldsError = false;
    foreach( $kdb as $k=>$base ) {
        $name = ( $base['name'] != "" ? $base['name'] : "#".($k+1) );
        foreach( $bfields as $bf ) {
            if( trim($base[$bf]) == "" ) {
                $errBaseFieldsError = true;
                $errBaseFields[] = "Base de données <strong>$name</strong> : le champ <strong>$bf</strong> est obligatoire";
            }
        }
    }
    if( $errBaseFieldsError )
        crashError( implode("<br/>",$errBaseFields));
    define('NODBMODE', false);
}
else define('NODBMODE', true);


/* User uploads */
if( !isset($GLOBAL_PARMS['directories']['user_uploads']) )
    crashError("Impossible de trouver la clé <strong>user_uploads</strong> dans <strong>directories</strong>");
$kup = $GLOBAL_PARMS['directories']['user_uploads']; 
foreach( ["tmp","store"] as $o ) {
    if( !isset($kup[$o]) ) $kup[$o] = "";
    $cdir = kRoot().$kup[$o];
    if( $kup[$o] != "" && ( !is_dir($cdir) || !is_readable($cdir) || !is_writable($cdir) ) ) {
        if( !is_dir($cdir) ) {
            try {
                $u = umask(0);
                mkdir( $cdir, 0777 );
                umask($u);
            }
            catch( Exception $e ) {
                crashError("Impossible de créer le dossier : ".$cdir);
            }
        }
        if( !is_readable($cdir) || !is_writable($cdir) ) {
            crashError("
                Les dossiers <strong>user_uploads</strong> dans <strong>directories</strong><br/>
                doivent êtres créés et accessibles en lecture/écriture.
            ");
        }
    }
}



/* Paths */
global $kDirectories;
$kDirectories = [];
if( isset($GLOBAL_PARMS['directories']['mypaths']) ) {
    $mp = $GLOBAL_PARMS['directories']['mypaths'];
    if( is_array($mp) ) {
        foreach( $mp as $p ) {
            if( !isset($p['path']) ) continue;
            $p['path'] = path($p['path']);
            if( !file_exists($p['path']) ) {
                try{
                    mkdir( $p['path'], 0777, true );
                }
                catch( Exception $e ) {
                    crashError("Le dossier n'existe pas ou est innaccessible : ".$p['path']);
                }
            }
            if( isset($p['readOnly']) ) {
                if( $p['readOnly'] && !is_readable($p['path']) )
                    crashError("Droits de lectures insuffisants sur : ".$p['path']);
            }
            if( !isset($p['readOnly']) || $p['readOnly'] == false ) 
                if( !is_writable($p['path']) )
                    crashError("Droits de lecture & écriture insuffisants sur : ".$p['path']);  
            if( isset($p['name']) && $p['name'] != "" )
                $kDirectories[$p['name']] = $p['path'];
        }
    }

    if( !function_exists('myDir') ) {
        function myDir( $name = null, Bool $asbolute = false ) {
            global $kDirectories;
            return isset($kDirectories[$name]) ? ($asbolute?kroot():'').$kDirectories[$name] : null;
        }      
    }
}
