<?php
#[AllowDynamicProperties]
class Datas {
    public Array $prop = [];
}

#[AllowDynamicProperties]
class Post {

    public $p;

    public function __construct( Array $datas = [] ) {
        global $Kernelite;
        $this->p = empty($datas) ? $Kernelite->req->post : $datas;
        $this->assoc();
    }
    public function assoc() {
        foreach( $this->p as $key => $value ) 
            $this->{$key} = $value;
        unset($this->p);
    }
    public function __get($name) {
        return $this->{$name} ?? null;
    }
    public function __set($key,$value){
        $this->{$key} = $value;
    }
    public function toArray() {
        $records = [];
        foreach( $this as $key => $value ) 
                $records[$key] = $value;
        return $records;
    }
}

