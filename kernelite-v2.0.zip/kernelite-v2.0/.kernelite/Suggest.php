<?php

class Suggest {
    
    private Array $params;
    private DataManager $dm;
    private String $term;
    private String $struc;

    public function __construct ( DataManager $dm, Logger $logger, Array $req) {
        $this->params = $req['queryString'];
        $this ->dm = $dm;
        

        # Récupération des parametres
        if( !isset($this->params['splited'][2]) )
            throw new KernelError("Impossible de procéder au suggestion car aucune structure");
        $tmp = explode(";",$this->params['splited'][2]);
        if( !in_array(count($tmp),[2,3]) )
            throw new KernelError("Problèmes avec les paramètres de suggestion");
        
        # Structure initiale et champ
        $fieldStruc = $tmp[0];
        $field = $tmp[1];
        $filters = $this->params['splited'][3];
        
        # Term
        $pos = strpos($this->params['raw'],'&term=');
        if( $pos < -1 ) core::apiSuccess(["datas" => []]);
        $this->term = substr($this->params['raw'], $pos+6);
        if( strlen($this->term) < 2 ) core::apiSuccess(["datas" => []]);


        if( !Structure::exists($fieldStruc))
            throw new KernelError("Structure $fieldStruc inexistante");

        # Chargement de la structure initiale
        $s = Structure::get($fieldStruc);
        # Test de l'existance du champ initial dans la structure initiale
        if( !isset($s[$field]) || !isset($s[$field]['suggest']) )
        throw new KernelError("Suggest : le champ $field est introuvable dans ".$fieldStruc);

        $params = $s[$field]['suggest'];
        $this->struc = $params['structure'];
        if( !Structure::exists($this->struc))
            throw new KernelError("Structure $fieldStruc inexistante");   


        if( isset($params['controller']) ) {
            try {
                if( strpos($params['controller'],"::") > - 1 ) {
                    list($classe,$methode) = explode("::",$params['controller']);
                    $obj = new $classe();
                    if( !method_exists($obj,$methode) )
                        throw new KernelError("La méthode $methode n'existe pas dans $classe");
                    
                    $pos = strpos($filters,':')+1;
                    $filters = substr($filters,$pos);

                    call_user_func_array( [$obj,$methode],[$dm,$req,$this->term,$filters] );
                }
            } catch(Exception $e) {
                throw new KernelError($e->getMessage());
            }
            die('{}');
        }
        
        # Récupération de la structure cible
        $searchStructure = Structure::get($this->struc);

        # Test des champs de recherche dans la structure cible
        $fields = ['libelle'];
        if( isset($params['field']) )
            $fields = explode(",",$params['field']);
        foreach( $fields as $a=>$b ) $fields[$a] = trim($b);
        foreach( $fields as $field ) {
            if( !isset($searchStructure[$field]) )
            throw new KernelError("Le champ $field n'existe pas dans $fieldStruc");
        }
        
        # Valeurs de retours
        $returnFields = ['libelle'];
        if( isset($params['return']) )
            $returnFields = explode(",",$params['return']);
        foreach( $returnFields as $a=>$b ) $returnFields[$a] = trim($b);
        foreach( $returnFields as $field ) {
            if( !isset($searchStructure[$field]) )
            throw new KernelError("Le champ $field n'existe pas dans $fieldStruc");
        }        

        # Check sécurité
        self::checkSuggestSecurity($this->struc, $logger);


        $filter = [];
        foreach( $fields as $field ) {
            $filter["%".$field] = $this->term;
        }
        

        $dm->findAll($this->struc,[
            "filter" => $filter,
            "operator" => "OR",
            "limit" => 30
        ]);
        
        $rez = $dm->getByField('id');
        $rep = [];
        foreach( $rez as $k=>$e ) {
            if( isset($e['deleted']) && $e['deleted'] == 1 ) continue;
            $add = true;
            # Filters
            if( $filters != "" && strpos($filters,":") > -1 ) {
                list(,$q) = explode(":",$filters);
                try { parse_str($q,$tab); }
                catch( Exception $e ) { throw new KernelError("Impossible d'appliquer les filtres d'autocompletion");}
                if( !empty($tab) ) 
                    foreach( $tab as $field => $value ) 
                        if( array_key_exists($field,$e) && $e[$field] != $value && $value != "" ) 
                            $add = false;
            }
            if( !$add ) 
                continue;


            $val = [];
            foreach( $returnFields as $f ) $val[] = $e[$f];
            $val = implode(" ",$val);
            $rep[] = [
                "id" => $k,
                "label" => $val,
                "value" => $val
            ];
        }
        die(json_encode($rep));
    }


    private static function checkSuggestSecurity( String $structure, Logger $logger ) {
        $securityFile = Spyc::YAMLLoad( join_paths([CONF,'security.yaml']) );
        if( 
            !$securityFile
            || !isset($securityFile['suggest']) 
            || empty($securityFile['suggest']) 
            || $securityFile['suggest'] == "" 
        ) return;
        $suggestRules = $securityFile['suggest'];
        //dd($securityFile['suggest']);
        if( !array_key_exists($structure,$suggestRules) ) return;

        $userRule = $suggestRules[$structure];
        if( !$logger->userMatchRule( $userRule ) ) 
            throw new KernelError("Vous n'avez pas le droit d'obetnir les suggestions demandées");

    }

}