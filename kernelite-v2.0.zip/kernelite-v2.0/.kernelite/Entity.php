<?php
#[\AllowDynamicProperties]
abstract class Entity {

    public Int $id;
    public DataManager $dm;
    public String $className;
    public String $structure;
    public Bool $inited = false;
    public Array $object;

    abstract  public function create() : Int; // Must be implemanted



    public function __init( Int $id = 0 ) {
        $this->dm = dm();
        $this->_setStructure();
        $this->id = $id > 0 ? $id : $this->_findId();
        if( $this->id  < 1 ) return;
        $this->inited = true;
        $this->init();
    }
    public function init() {
        $this->_loadDatas()->_objectify();
    } // User init
    public function _findId() {
        $id = (new Controller())->getSlug();
        if( !$id || !$this->_exists($id) ) $id = (new Post())->id ?? 0;
        if( !$id || !$this->_exists($id) ) $id = $this->findIdCustom();
        $id = intval($id);
        return $this->_exists($id) ? $id : 0;
    }
    public function findIdCustom() : Int {
        return 0;
    }
    public function _setStructure() {
        $this->className = get_class($this);
        $this->structure = mb_strtolower($this->className);
        if( !Structure::exists($this->structure) )
            err("[Entity] La structure {$this->structure} n'existe pas.");
    }
    public function getId() {
        if( $this->id < 1 )
            return false;
        return $this->id;
    }
    public function get() {
        $array = [];
        foreach( $this as $k=>$e ) {
            if( gettype( $e ) == "object" ) continue;
            $array[$k] = $e;
        }
        return $array;
    }
    public function _unset() {
        foreach( $this as $k=>$e ) {
            switch( $k ) {
                case 'dm' : {
                    break;
                }
                case 'id' : {
                    $this->{$k} = 0;
                    break;
                }
                default : 
                    $this->{$k} = null;
            }
        }
        $this->id = 0;
        return $this;
    }

    public function _me() {
        if( !$this->inited || !$this->id ) err("[Entity] _me() ne peut pas être appelé sur une entité nont initialisée");
        return $this->dm->use($this->structure,$this->id);
    }
    public function _exists( Int $id = 0 ) {
        return $this->dm->find($this->structure, $id ?? $this->id)->count() == 1;
    }
    public function _loadDatas() {
        if( !$this->inited || !$this->id ) err("[Entity] _loadDatas() ne peut pas être appelé sur une entité nont initialisée");
        $this->object = $this->_me()->getArray();
        return $this;
    }
    public function _updateField( String $field, mixed $value ) {
        if( !$this->inited || !$this->id ) err("[Entity] _updateField() ne peut pas être appelé sur une entité nont initialisée");
        $this->{$field} = $this->object[$field] = $value;
        return $this->_me()->set($field,$value);
    }
    public function _objectify() {
        if( empty($this->object) ) return;
        foreach( $this->object as $k=>$e )
            $this->{$k} = $e;    
        return $this;
    }
}