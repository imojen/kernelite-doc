<?php

class mysqlObject {

    public $link;
    public $defineTables;

    public $credentials;


    public function __construct( $credentials = [] ) {
        $this->credentials = $credentials;
        if( empty($this->credentials) ) {
            $this->credentials = [
                "host" => DB_HOST,
                "user" => DB_USER,
                "password" => DB_PASS,
                "base" => DB_NAME
            ];
        }
        $this->defineTables = " SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = '".$this->credentials['base']."' ";       
    }


    public function createConnection( $retry = false ) {
		$this->link = @mysqli_connect( 
            $this->credentials['host'], 
            $this->credentials['user'], 
            $this->credentials['password']
        );
		if( !$this->link ) 
			crashError("Impossible de se connecter à la base de données");
        
        try {
		    mysqli_select_db( $this->link, $this->credentials['base']);
        }
        catch( Exception $e ) {
            if( !$retry ) {
                $this->createDatabase( $this->credentials['base'] );
                return $this->createConnection(true);
            }
            crashError("Impossible de séléctionner la base de données : ".$this->credentials['base']);            
        }
		
		mysqli_set_charset($this->link,"UTF8");
        $this->query($this->link,"SET sql_mode = '' ");
		return $this->link;        
    }  
    
    public function createDatabase( $databaseName ) {
        $s = $this->query( $this->link, 'CREATE DATABASE `'.$this->escape($databaseName).'` CHARACTER SET utf8 COLLATE utf8_general_ci');
        if( !$s ) crashError( $this->getError() );
        return $this;
    }

    public function query( $link, $sqlQuery ) {
        return mysqli_query( $link, $sqlQuery );
    }

    public function getError() {
        return mysqli_error($this->link);
    }

    public function getLastId() {
        return mysqli_insert_id($this->link);
    }

    public function assoc( $object ) {
        return mysqli_fetch_assoc( $object );
    }

    public function count( $object ) {
        return mysqli_num_rows( $object );
    }

    public function rows( $object ) {
        return mysqli_fetch_row($object);
    }

    public function escape( $object ) {
        return mysqli_real_escape_string( $this->link, $object );
    }

    public function defineTablesFields( $table ) {
        return "SELECT  COLUMN_NAME as name ,DATA_TYPE as type,CHARACTER_MAXIMUM_LENGTH as max_length
        FROM information_schema.COLUMNS  WHERE 
        TABLE_SCHEMA = '".$this->credentials['base']."' 
        AND TABLE_NAME = '".$this->escape($table)."'
        ";
    }

}