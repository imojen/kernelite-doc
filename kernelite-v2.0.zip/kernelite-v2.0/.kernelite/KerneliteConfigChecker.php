<?php

class KerneliteConfigChecker {

    public function __construct(){

        # BDD
        if( DATAMANAGER ) {
            if( DB_HOST == "" || DB_USER == "" || DB_PASS == "" || DB_NAME == "" ) {
                throw new KernelError("[ConfigChecker] La configuration de la base de données est incomplète");
            }
        }


    }

}