<!DOCTYPE html>
<html lang="fr">
    <head>
        <title>.kernelite</title>
        <link rel="icon" href="./assets/css/vendor/images/kernelite-logo-sm.png" type="image/png">
        <style type="text/css">
            .body {
                font-family: Arial, Helvetica, sans-serif;
                margin:50px auto;
                max-width: 800px;
                text-align:center;
            }
            .body img {
                width: 60%;
            }
            .body p.title {
                background:#D32F2F;
                color:#FFFFFF;
                line-height: 30px;
                font-size: 16px;
                font-weight: normal;
                padding: 20px 10px;
                margin: 0 auto;
                border-bottom: 4px solid #B71C1C;
            }   
            .body p.msg {         
                margin-top: 0px;
                font-size: 16px;
                background: #eee;
                color: #444;
                padding: 20px;
                border-bottom: 2px solid #ddd;
                line-height: 30px;
            }
        </style>
    </head>
    <body>
        <div class="body" >
            <img src="<?php echo defined('URL') ? URL : '.';?>/assets/css/vendor/images/kernelite-logo-m.png" title=".kernelite" alt=".kernelite Logo" />
            <p class="title">Configuration .kernelite incorrecte</p>
            <p class="msg">
                <?php echo $msg;?>
            </p>
    </body>
</html>