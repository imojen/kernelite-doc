<?php

class Logger {

    private Request $req;
    private $dm;
    private Bool $useLogger;
    private Bool $connexionStatus;
    private Array $securityFile;
    private Array $loggerInfo;
    private String $tableName;
    private String $loginFieldName;
    private String $passwordFieldName;
    private String $lastLoginDateName;
    private Array $loginConditions;
    public Bool $loginAttemptStatus;
    public Bool $loginAttemptSuccess;
    private Array $session;
    private Bool $useRules;
    public Array $rules;
    public String $logoutRoute;
    private String $logoutRedirect;
    private Array $suggestSecurity;
    private Controller $controller;
    private $Kernelite;
    private Kernelite $Framework;
    private Bool $hashPassword;

    public function __construct( Request $req, $dm ) {
        $this->req = $req;
        $this->dm = $dm;
        $this->useLogger = DATAMANAGER;
        $this->logoutRoute = "";

        global $Kernelite;
        $this->Framework = $Kernelite;
        $this->controller = new Controller();

        if( !$this->useLogger ) return;

        $this->loadSecurity();
        if( !$this->useLogger )
            return;

    }

    public static function getSecurity() {
        return Spyc::YAMLLoad( join_paths([CONF,'security.yaml']) );
    }    
    private function loadSecurity() {
        $this->securityFile = self::getSecurity();

        if( !isset($this->securityFile['logger']) ) {
            $this->useLogger = false;
            return $this;
        }
        $this->loggerInfo = $this->securityFile['logger'];

        if( 
            !isset($this->loggerInfo['fields']['login']) 
            || !isset($this->loggerInfo['fields']['password']) 
            || !isset($this->loggerInfo['table'])
            || !isset($this->loggerInfo['hash'])
        )
            throw new KernelError("Fichier de sécurité mal déclaré ou incomplet");

        $this->tableName = $this->loggerInfo['table'];
        $this->loginFieldName = $this->loggerInfo['fields']['login'];
        $this->passwordFieldName = $this->loggerInfo['fields']['password'];
        $this->hashPassword = $this->loggerInfo['hash'];
        $this->lastLoginDateName = $this->loggerInfo['last_login_date'] ?? null;
            
        $this->loginConditions = [];
        if( isset($this->loggerInfo['conditions']) ) {
            $this->loginConditions = $this->loggerInfo['conditions'];
        }


        // Rules 
        if( !isset($this->securityFile['rules']) ) {
            $this->useRules = false;
            return $this;
        }   
        if( 
            !isset($this->securityFile['logout']['url'])
            || !isset($this->securityFile['logout']['redirect'])
        ) {
            throw new KernelError("Il manque des parametres pour la deconnexion");
        }
        $this->logoutRedirect = $this->securityFile['logout']['redirect'];
        $this->logoutRoute = $this->securityFile['logout']['url'];
        $this->useRules = true;
        foreach( $this->securityFile['rules'] as $name => $r ) {
           $this->rules[$name] = $r;
        }

        return $this;
    }

    public function checkConnected() {
        $this->connexionStatus = false;
        if( isset($this->req->session['connected']) && $this->req->session['connected'] === true ) {
            $this->connexionStatus = true;
            define('USERID',$this->req->session['user']['id'] ?? 0 );
        }
        return $this;
    }

    public function isConnected() {
        if( !$this->useLogger ) return false;        
        return $this->connexionStatus;
    }

    public function checkLoginAttempt() {
        if( !$this->useLogger ) return false;  
        $this->loginAttemptStatus = false;
        $this->loginAttemptSuccess = false;

        if( 
            isset($this->req->post[ $this->loginFieldName ])
            && isset($this->req->post[ $this->passwordFieldName ])
            && !$this->isConnected()
            && count($this->req->post) == 2
        ) {
            
            $this->loginAttemptStatus = true;
            $login = $this->req->post[ $this->loginFieldName ];
            $password = $this->req->post[ $this->passwordFieldName ];

            if( $this->hashPassword ) 
                $password = core::salt($password,$this->dm->salt,$this->dm->saltOrder);
            
            $this->dm->findAll($this->tableName,[
                "filter" => [
                    $this->loginFieldName => $login,
                    $this->passwordFieldName => $password
                ]
            ]);

            if( $this->dm->count() == 0 ) {
                $this->loginAttemptSuccess = false;
                return $this;
            }
            $infos = $this->dm->getRow();

            if( !empty($this->loginConditions) ) {
                $canConnect = true;
                foreach( $this->loginConditions as $field => $value ) {
                    if( !isset($infos[$field]) )
                        continue;
                    if( $infos[$field] != $value )
                        $canConnect = false;
                }
                if( !$canConnect ) {
                    $this->loginAttemptSuccess = false;
                    return $this;                    
                }
            }

            if( $this->lastLoginDateName ) 
                $this->dm->use($this->tableName, $infos['id'])->set( $this->lastLoginDateName, date("Y-m-d G:i:s"));
            $this->loginAttemptSuccess = true;
            $this->openSession($infos);
        }
        return $this;
    }

    public function loginFromLdap( Array $params ) {
        if( $this->loginFieldName == "" ) 
            err("[Logger] Veuillez définir le champ logger > fields > login dans security.yaml");
        if( !isset($params[$this->loginFieldName]) )
            err("[Logger] Le champ ".$this->loginFieldName." n'a pas été reçu");

        $this->loginAttemptStatus = true;
        $this->loginAttemptSuccess = true;

        $this->dm->findAll( $this->tableName,["filter"=> [
            "deleted" => 0,
            $this->loginFieldName => $params[$this->loginFieldName]
        ]]);
        if( $this->dm->count() == 0 ) {
            $this->dm->create( $this->tableName, $params);
            $id = $this->dm->getLastId();
        }
        else {
            $id = $this->dm->get('id');
            $this->dm->use( $this->tableName, $id )->multiSet($params);
        }
        $params['id'] =  $id;

        if( $this->lastLoginDateName && $this->lastLoginDateName != "" )
            $this->dm->use( $this->tableName, $id )->set($this->lastLoginDateName, date("Y-m-d G:i:s"));

        $this->openSession( $params );
        return $this;
    }

    public function getLoginAttemptState() {
        return $this->loginAttemptSuccess;
    }

    private function openSession( $infos ) {
        $this->req->session['connected'] = true;
        $this->req->session['user'] = $infos;
        $_SESSION = $this->req->session;
        return $this;
    }

    public function userMatchRule( $ruleName ) {
        if( !$this->useLogger )
            throw new KernelError("Vous ne pouvez pas définir de sécurité de route sans utilier Logger");
        if( !isset($this->rules[$ruleName]) ) 
            throw new KernelError("Cette règle de sécurité n'est pas définie : $ruleName");
        $r = $this->rules[$ruleName];
        if( empty($r) )
            return true;
        if( isset($r['logger']) && $r['logger'] === true &&  !$this->isConnected() )
            return false;
        if( isset($r['logger']) && $r['logger'] === false &&  $this->isConnected() )
            return false;
        if( isset($r['fields']) ) {
            foreach( $r['fields'] as $field => $value ) {
                if( !isset($this->req->session['user'][$field]) )
                    throw new KernelError("La règle de sécurité $ruleName test un champ qui n'existe pas dans la session : $field");
                if( $this->req->session['user'][$field] != $value )                
                    return false;
            }
        }
        return true;
    }

    public function securityRedirect( Controller $c, $route ) {
        if( !isset($route['securityRedirect']) )
            return false;
        $c->redirectToRoute($route['securityRedirect']);
    }

    public function checkLogout() {
        if( isset($this->logoutRoute) && $this->req->route['url'] == $this->logoutRoute ) {
            $this->logout();
            if( $this->req->api === true ) {
                $this->Framework->apiResponse([]);
            }
            $this->controller->redirectToRoute($this->logoutRedirect != "" ? $this->logoutRedirect : $this->Framework->routeObj->getDefaultRoute()['name']);
        }
        return $this;
    }

    public function logout() {
        $this->req->session = [];
        $_SESSION = [];
        $_COOKIE = [];
        $this->connexionStatus = false;
    }

    public function getLogoutRoute() {
        return $this->logoutRoute;
    }




    public function apiLogin() {
        // if( isset($this->req->post[API_TOKEN_NAME]) && $this->req->post[API_TOKEN_NAME] != "" ) {
        //     $tokenInfo = $this->kTokenExist($this->req->post[API_TOKEN_NAME]);
        //     if( $tokenInfo ) {
        //         if( strtotime($tokenInfo[API_TOKEN_EXPIRE]) >= strtotime('now') ) {
        //             $this->dm->use(API_TOKEN_STRUC,$tokenInfo['id'])->set(API_TOKEN_EXPIRE, $this->getTokenExpirationDelay() );
        //             core::apiSuccess(["token" => $this->req->post[API_TOKEN_NAME]]);
        //         }
        //     }
        // }

        $this->loginAttemptStatus = true;
        $login = $this->req->post[ $this->loginFieldName ];
        $password = $this->req->post[ $this->passwordFieldName ];
        if( $this->hashPassword ) 
            $password = core::salt($password,$this->dm->salt,$this->dm->saltOrder);

        $this->dm->findAll($this->tableName,[
            "filter" => [
                $this->loginFieldName => $login,
                $this->passwordFieldName => $password
            ]
        ]);
        if( $this->dm->count() != 1 ) 
            die(json_encode(core::apiError("Veuillez vérifier vos identifiants")));
        $infos = $this->dm->getRow();

        if( !empty($this->loginConditions) ) {
            $canConnect = true;
            foreach( $this->loginConditions as $field => $value ) {
                if( !isset($infos[$field]) )
                    continue;
                if( $infos[$field] != $value )
                    $canConnect = false;
            }
            if( !$canConnect ) {
                die(json_encode(core::apiError("Connexion non autorisée")));                  
            }
        }

        $kToken = core::generateString(45);
        $this->dm->use($this->tableName, $infos['id'])->multiSet([
            API_TOKEN_NAME => $kToken,
            API_TOKEN_EXPIRE => $this->getTokenExpirationDelay()
        ]);
        if( $this->lastLoginDateName ) 
            $this->dm->use($this->tableName, $infos['id'])->set( $this->lastLoginDateName, date("Y-m-d G:i:s"));

        $kRemoveFields = [$this->passwordFieldName,API_TOKEN_NAME,API_TOKEN_EXPIRE];
        foreach( $kRemoveFields as $field ) if( isset($infos[$field]) ) unset($infos[$field]);

        core::apiSuccess(["kToken" => $kToken,"user" => $infos]);
    }
    public function kTokenExist( $token ) {
        $this->dm->findAll(API_TOKEN_STRUC,[
            "filter" => [
                API_TOKEN_NAME => $token
            ]
        ]);
        return $this->dm->count() == 1 ? $this->dm->getRow() : false;
    }
    public function getTokenExpirationDelay() {
        return date('Y-m-d H:i:s', strtotime('+'.API_TOKEN_DELAY.' seconds'));
    }
    public function checkTokenValidity() {
        if( !isset($this->req->post[API_TOKEN_NAME]) || $this->req->post[API_TOKEN_NAME] == "" ) return $this->tokenExpires();
        $u = $this->kTokenExist( $this->req->post[API_TOKEN_NAME] );
        if( !$u || strtotime($u[API_TOKEN_EXPIRE]) < strtotime('now') ) return $this->tokenExpires();
        http_response_code(200);
        die('{"token_valid" : true}');
    }
    public function tokenExpires( $type = 0 ) {
        http_response_code(401);
        die(json_encode([
            "token_valid" => false,
            "type" => $type
        ]));
    }
    public function openApiSession() {
        if( !isset($this->req->post[API_TOKEN_NAME]) || $this->req->post[API_TOKEN_NAME] == "" ) return $this->tokenExpires(1);
        $u = $this->kTokenExist( $this->req->post[API_TOKEN_NAME] );
        if( !$u || strtotime($u[API_TOKEN_EXPIRE]) < strtotime('now') ) return $this->tokenExpires(2);
        $this->loginAttemptSuccess = true;
        $this->openSession($u);
        unset($this->req->post[API_TOKEN_NAME]);
    }





}