<?php

class Structure {

    public static function _load( DataManager $dm ) {
        $files = core::getFilesFromDir(STRUC);
        if( empty($files) ) return;
        foreach( $files as $file ) {
            if( strpos($file,".yaml") < 0 ) continue;
            $name = core::getFileName($file,false);
            $structure = Structure::get($name);             
            if( $structure && !empty($structure) ) {
                Structure::processStructure( $dm, $name, $structure );
            }
        }
        return;
    }

    public static function get( String $name ) {
        $path = join_paths([STRUC,$name.".yaml"]);
        if( !self::exists($name) )
            throw new KernelError("Impossible de charger la structure $name car introuvable<br/>$path");
        $file = Spyc::YAMLLoad( $path );

        if( API_ONLY && isset($file[$name]) ) {
            if( $name == API_TOKEN_STRUC ) {
                $found_ktoken_field = false;
                foreach( $file[$name] as $k=>$e ) {
                    if( $k == API_TOKEN_NAME ) {
                        $found_ktoken_field = true;
                        break;
                    }
                }
                if( !$found_ktoken_field ) {
                    $file[$name][API_TOKEN_NAME] = [
                        "is" => "string"
                    ];
                    $file[$name][API_TOKEN_EXPIRE] = [
                        "is" => "date"
                    ];
                }
            }
        }

        return $file[$name] ?? false;
    }

    public static function exists( String $name ) {
        $path = join_paths([STRUC,$name.".yaml"]);
        return file_exists($path);
    }

    public static function getFormCustomization( String $type ) {
        global $GLOBAL_PARMS;
        return $GLOBAL_PARMS['customization']['form']['classes'][$type] ?? false;
    }
    public static function getFormRequiredCustomization() {
        global $GLOBAL_PARMS;
        return $GLOBAL_PARMS['customization']['form']['required'] ?? false;
    }

    public static function getForm( String $name, String $widget = null, String $form = "form" ) {
        $sname = $name;

        /* Load customization */
        $formTagsClasses = self::getFormCustomization('generic') ?? 'form-control form-control-lg';
        $requiredClassName = self::getFormCustomization('required') ?? 'isRequired';
        $labelClassName = self::getFormCustomization('label') ?? '';
        $wrapperClassName = self::getFormCustomization('wrapper') ?? 'form-group';
        $req_tmp = self::getFormRequiredCustomization();
        $req_addSymbol = $req_tmp['addSymbol'] ?? true;
        $req_Symbol = $req_tmp['symbol'] != "" ? $req_tmp['symbol'] : "*";

        $s = self::get(trim($name));
        $o = [];
        foreach( $s as $name => $p ) { 
            if( $widget !== null && $name != $widget ) continue;
            if( isset($p['hide']) && $p['hide'] == true ) {
                if( $name != $widget ) continue;
            }
            if( !isset($p['ph']) ) $p['ph'] = "";
            if( !isset($p['type']) ) err("Le champ $name n' pas de type de champ dans sa structure");
            
            $value = $name;
            $required = ( isset($p['required']) && $p['required'] === true );
            $reqClass = $required ? $requiredClassName : '';
            $symbol = ( $required && $req_addSymbol ? $req_Symbol : "" );

            if( $form != "" ) $value = $form.".".$name;
            $dis = isset($p['disabled']) && $p['disabled'] ? 'disabled' : '';
            $class = isset($p['class']) && trim($p['class']) != "" ? trim($p['class']) : '';

            $label = $endLabel = "";
            if( isset($p['label']) && $p['label'] != "") {
                $label = '<div class="'.$wrapperClassName.'">';
                $label .= '<label class="'.$labelClassName.'" for="form_'.$name.'">';
                $label .= $p['label'].' '.$symbol.'</label>';
                $endLabel = '</div>';
            }

            /** Suggestion **/
            $suggest = "";
            if( isset($p['suggest']) ) {
                if( !is_array($p['suggest']) || !isset($p['suggest']['structure']) )
                    throw new KernelError("Erreur de structure : $sname > $name > suggest");
                if( !Structure::exists($p['suggest']['structure']) )
                    throw new KernelError("Suggest structure introuvable : $sname > $name > suggest");
                $idField = $p['suggest']['idField'] ?? "";
                $svalue = $sname.';'.$name.'|'.$idField.'|';

                # Filters
                if( isset($p['suggest']['filter']) ) {
                    $tmp = [];
                    foreach( $p['suggest']['filter'] as $field => $el ) 
                        $tmp[] = $field.":".$el;
                    $svalue .= implode(";",$tmp);
                }
                $suggest = ' data-kernelite-suggest="'.$svalue.'" ';

                if( isset($p['suggest']['callback']) ) 
                    $suggest.= 'data-kernelite-suggest-callback="'.$p['suggest']['callback'].'" ';
                
            }

            /* Form Tags Types */
            if( $p['type'] == "select") {
                $options = self::getFormOptions( $p['options'] );
                $o[] = $label;
                $o[] = '<select name="'.$name.'" class="'.$formTagsClasses.' '.$reqClass.' '.$class.' " id="form_'.$name.'" ';
                $o[] = ' data-kernelite-value="{{ '.$value.' }}" ';
                $o[] = ' data-kernelite-default="'.($p['default']??"").'" ';
                $o[] = ' '.$dis.' >';
                $o[] = $options;
                $o[] = '</select>';
                $o[] = $endLabel;
            }
            elseif(  $p['type'] == "textarea") {
                $o[] = $label;
                $o[] = '<textarea name="'.$name.'" class="'.$formTagsClasses.' '.$reqClass.' '.$class.'" '.$dis.' placeholder="'.$p['ph'].'" id="form_'.$name.'">{{ '.$value.' }}</textarea>';
                $o[] = $endLabel;
            }
            elseif( $p['type'] == "hidden" ) {
                $o[] = '<input type="hidden" name="'.$name.'" id="'.$name.'" value="{{ '.$value.' }}"/>';
            }            
            else {
                $o[] = $label;
                $o[] = '<input type="'.$p['type'].'" autocomplete="off" name="'.$name.'" '.$dis.' '.$suggest.' class="'.$formTagsClasses.' '.$reqClass.' '.$class.'" id="form_'.$name.'" value="{{ '.$value.' }}" placeholder="'.$p['ph'].'"/>';
                $o[] = $endLabel;
            }

        }
        return implode($o);
    }

    public static function printForm( String $name, String $widget = null, String $form = "form" ) {
        echo Structure::getForm($name,$widget,$form);
    }

    public static function getOptions( String $structure, String $field ) {
        return self::get($structure)[$field]['options'] ?? false;
    }

    private static function getFormOptions( $options ) {
        if( is_array($options) && empty($options) )
            return "";
        if( is_string($options) && $options == "" )
            return "";
        if( is_string($options) ) {
            $s = s($options);
            if( !$s )
                throw new KernelError("La structure $options n'existe pas");
            global $Kernelite;
            if( !isset($s['libelle']) )
            throw new KernelError("La structure $options doit avoir un champ libelle pour génerer des options");
            $options = $Kernelite->dm->findAll($options,[
                "filter" => ["deleted" => 0]
            ])->getByField('id','libelle');            
        }
        $str = ['<option></option>'];
        foreach( $options as $k=>$e )
            $str[] = '<option value="'.$k.'">'.$e.'</option>';
        
        return implode($str);
    }

    public static function processStructure( DataManager $dm, String $name, Array $struc ) {
        if( !$dm->isMainDatabase() ) return;
        if( !in_array($name, $dm->getTables()) ) {
            if( StructureInspector::checkStructureIntegrity( $name, $struc ) ) {
                self::createStructure($dm,$name,$struc );
                self::injectDatas($dm,$name,$struc );
            }
        }
        else 
            self::updateStructure($dm,$name,$struc);
        return;
    }

    private static function createStructure( DataManager $dm, String $name, Array $struc ) {
        if( !$dm->isMainDatabase() ) return;
        $query = $indexes = [];
        $pre = ( DB_MODE == "mysql" ? DB_NAME.'.' : '' );
        $query[] = 'CREATE TABLE '.$pre.$name.' (';
        $ac = ( DB_MODE == "mysql" ? 'AUTO_INCREMENT' : 'IDENTITY(1, 1)');
        $fields = [' id INT NOT NULL  '.$ac.' PRIMARY KEY'];
        $created = 0;
        foreach( $struc as $fieldName => $f ) {
            if( $f['is'] == null ) continue;
            if( in_array($fieldName,["id","date_creation","date_modification","deleted"]) )
                continue;            
            $fields[] = self::getFieldCreation($fieldName,$f);
            if( isset($f['index']) && $f['index'] === true )
                $indexes[] = ' INDEX( `'.$fieldName.'` ) ';
            $created++;
        }
        if( $created == 0 )
            return;
        $fields[] = " date_creation DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ";
        $fields[] = " date_modification DATETIME ".( DB_MODE == "mysql" ? "ON UPDATE CURRENT_TIMESTAMP" : "" )."  NULL ";
        $fields[] = " deleted TINYINT NOT NULL DEFAULT '0' ";
        if( !empty($indexes) &&  DB_MODE == "mysql" ) $fields[] = implode(",",$indexes);
        //$fields[] = ' PRIMARY KEY (id) ';
        $query[] = implode(' , ',$fields);
        $query[] = ')'; #ENGINE = InnoDB

        $dm->query( implode($query) );
        if( !$dm->successQuery )
            err("Erreur lors de la création de la structure $name");
        $dm->setStructure();

        return;
    }

    private static function injectDatas( DataManager $dm, String $name, Array $struc ) {
        if( !$dm->isMainDatabase() ) return;
        $path = join_paths([STRUC,'datas',$name.".yaml"]);
        if( !file_exists($path) || !is_readable($path) ) return;
        $file = Spyc::YAMLLoad( $path );
        $datas = StructureInspector::datasChecker( $name, $struc, $file );
        $datas = self::formatDatas($datas);
        $dm->create($name,$datas);
        return;
    }

    private static function formatDatas( $datas ) {
        foreach( $datas as $num_line => $line ) {
            foreach( $line as $field => $value ) {
                if( mb_strpos($field,'date') > -1 ) { # dd/mm/YYYY => YYYY-mm-dd
                    if( mb_strpos($value,'/') > -1 && mb_strlen($value) == 10 ) {
                        $tmp = explode('/', $value );
                        if( count($tmp) == 3 )
                            $datas[$num_line][$field] = implode('-',array_reverse($tmp));
                    }
                }
            }
        }
        return $datas;
    }

    private static function updateStructure( DataManager $dm, String $name, Array $struc ) {
        if( !$dm->isMainDatabase() ) return;
        $fields = array_keys($dm->getTableFields($name));
        $last = $fields[count($fields)-1];
        $append = [];
        foreach( $struc as $fieldName => $f ) {
            if( $f['is'] == null ) continue;
            if( in_array($fieldName,["id","date_creation","date_modification","deleted"]) )
                continue;   
            if( !in_array($fieldName,$fields) )
                $append[] = "ALTER TABLE $name ADD ".self::getFieldCreation($fieldName,$f)." AFTER $last";
            $last = $fieldName;
        }       
        if( !empty($append) )
            foreach($append as $query)
                $dm->query($query)->setStructure();
        return;
    }

    private static function getFieldCreation( String $fieldName, Array $f ) {
        $default = 'NULL';
        if( isset($f['default']) )
            $default = "'".$f['default']."'";
        elseif( in_array($f['is'],['float','int']) ) 
            $default = 0;


        switch( $f['is'] ) {
            case 'integer' :
            case 'int' : {
                return " $fieldName INT NOT NULL DEFAULT $default ";
                break;
            }
            case 'double':
            case 'float' : {
                return " $fieldName FLOAT NOT NULL DEFAULT $default ";
                break;
            }            
            case 'string' : {
                return " $fieldName VARCHAR(255) NULL DEFAULT $default ";
                break;
            }
            case 'boolean' : {
                return " $fieldName BOOLEAN NULL DEFAULT $default ";
                break;
            }
            case 'date' : {
                return " $fieldName  TIMESTAMP NULL DEFAULT $default ";
                break;
            }
            case 'datetime' : {
                return " $fieldName  DATETIME NULL DEFAULT $default ";
                break;
            }            
            case 'text' : {
                return " $fieldName TEXT NULL DEFAULT $default ";
                break;
            }
            default :
                throw new KernelError("Type du champs $fieldName non supporté : ".$f['is']);
        }
    }




}