<?php
function magicAutoloader( $classe ) {
    $dirs = [
        CONTROLLERS,
        SERVICES,
        ENTITIES,
        join_paths([KERNELITE,'lib']),
        join_paths([KERNELITE,'DataObjects'])
    ];
    $extensions = ['Controller','Service',''];
    foreach($dirs as $dir ) {
        if( !file_exists($dir) ) continue;
        $list = array_diff(scandir($dir),[".",".."]);
        foreach( $list as $controller ) {
            foreach( $extensions as $ext ) {
                if( $controller === $classe.$ext.".php" ) {
                    require_once( join_paths([$dir,$controller]) );
                    return;
                }
                if( $controller == $classe && is_dir(join_paths([$dir,$controller])) ) {
                    $sublist = array_diff(scandir( join_paths([$dir,$controller]) ),[".",".."]);
                    foreach( $sublist as $subcontrollers ) {
                        if( strpos($subcontrollers,$ext.".php" ) > -1 ) {
                            require_once( join_paths([$dir,$controller,$subcontrollers]) );
                            return;
                        }
                    }
                }
            }
            # Inclure
            $fileName = str_replace('_',DIRECTORY_SEPARATOR,$classe);
            $path = join_paths([$dir,$fileName.".php"]);
            if( file_exists($path) ) {
                require_once($path );
                return;
            }

            # Iterator
            magicLibIterator( $classe, $dir );

        }
    }
    return;
}

function magicLibIterator( $classe, $path ) {
    $list = array_diff(scandir($path),[".",".."]);
    foreach( $list as $elem ) {
        $p = join_paths([$path,$elem]);
        if( !file_exists($p) ) continue;
        if( is_dir($p) ) magicLibIterator( $classe, $p );
        else {
            $tmp = explode(".",$elem);
            $ext = array_pop($tmp);
            $name = implode(".",$tmp);
            if( strtolower($classe) == strtolower($name) )
                require_once($p);
        }
    }
}