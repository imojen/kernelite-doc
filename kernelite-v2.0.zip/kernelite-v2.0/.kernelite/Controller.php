<?php

class Controller {

    private String $output;
    public Array $templateParameters;
    private String $includeTemplate;
    private String $controllerOutput;
    public Array $params;
    private $mustache;
    public Request $req;
    private Array $uri;
    public Logger $logger;
    private Array $bodyDatas;
    public $defaultTemplateParameters;

    public function __construct($params = []) {
        $this->params = $params;
        $this->mustache = new Mustache_Engine(array('entity_flags' => ENT_QUOTES));
        $this->uri = Kernelite::getSplitedParameters();
        $this->bodyDatas = [];
    }

    public function render( $template = "", Array $parameters = [], Array $options = [] ) {


        if( is_array($template) ) {
            if( !empty($parameters) ) $options = $parameters;
            $parameters = $template;
            $template = "";
        }

        $this->processTemplateParameters($parameters);
        $this->includeTemplate = $this->checkTemplate($template);
        $this->templateParameters['queryTemplate'] = $this->includeTemplate;
        $this->templateParameters['base'] = $this->checkBaseTemplate($this->templateParameters['base']);
        
        if( API_ONLY ) $this->apiModeLandingPage();

        
        // Render
        $this->controllerOutput = $this->processOutput( $this->templateParameters['queryTemplate'] );
        $this->output = $this->processOutput( $this->templateParameters['base'] );
        $this->output = str_replace("{%CONTROLLER%}",$this->controllerOutput,$this->output);
        $return = Events::emit('controller.renderParseEnd',$this->output);
        if( is_string($return) && $return != "" ) $this->output = $return;


        // Reaplces
        $this->processReplaces();

        // Append kernelite
        $this->appendKernelite();

        // Injection de plugins
        if( array_key_exists("plugins", $options) ) 
            $this->loadPlugins( $options['plugins'] );

        // Append Body
        $this->appendBodyDatas();

        // Print
        $this->printOutput();
    }

    private function processTemplateParameters( Array $parameters ) {
        $parameters = $this->completeParameters( $parameters );
        $base = $parameters['base'] ?? "base.template";
        
        // CHeck default base template
        if( isset($this->req->route['controller']) ) {
            $tmp = explode("::",$this->req->route['controller']);
            $class = $tmp[0];
            if( class_exists($class) && isset($class::$baseTemplate) && !isset($parameters['base']) )
                $base = $class::$baseTemplate;
        }
        
        $this->templateParameters = [
            "base" => $base,
            "defaultTemplate" => join_paths([KERNELITE,"templates","default.template.php"]),
            "queryTemplate" => null,
            "parameters" => $parameters
        ];
        return $this;
    }

    private function completeParameters( $parameters ) {
        $this->defineDefaultTemplateParameters();
        foreach( $this->defaultTemplateParameters as $k=>$e ) {
            if( !isset($parameters[$k]) )
            $parameters[$k] = $e;
        }
        return $parameters;
    }

    private function defineDefaultTemplateParameters() {
        global $Kernelite;
        $this->req = $Kernelite->req;
        $this->defaultTemplateParameters = [
            "project_name" => PROJECT_NAME,
            "project_url" => URL,
            "title" => $Kernelite->getRouteFunctionName()." | ".PROJECT_NAME,
            "favicon" => Events::emit('define.favicon', $this ) ?? URL."assets/css/vendor/images/kernelite-logo-sm.png",
            "logo" => file_exists(path(kroot().'assets/img/logo.jpg')) ? URL.'assets/img/logo.jpg' : '',
            "isConnected" => $Kernelite->logger->isConnected(),
            "logoutRoute" => $Kernelite->logger->getLogoutRoute(),
            "user" => $Kernelite->logger->isConnected() ? $Kernelite->req->session['user']: null,
            "customs" => Events::emit('define.defaultTemplateParameters', $this ),
            "date" => [
                "today" => date("d/m/Y"),
                "now" => date("H\hi\ms"),
            ]
        ];

        # Ajout des règles de sécurité
        $r = DATAMANAGER ? $Kernelite->logger->rules : [];
        if( !empty($r) ) {
            $this->defaultTemplateParameters['rules'] = []; 
            foreach( $r as $name => $params ) {
                $this->defaultTemplateParameters['rules'][$name] = $Kernelite->logger->userMatchRule($name);
            }
        }

    }

    private function checkTemplate( String $template = "", Bool $retry = false ) {
        if( trim($template) == "" && isset($this->req->route['controller']) ) 
            $template = strtolower(str_replace("::","/",$this->req->route['controller']));
        $template = str_replace(["/","\\"], DIRECTORY_SEPARATOR,$template);
        $tpl = join_paths([TEMPLATES,$template.".php"]);
        if( !file_exists($tpl) ) {
            if( !$retry ) {
                global $Kernelite;
                $this->req->route = $Kernelite->matchedRoute;
                return $this->checkTemplate("",true);
            }
            throw new KernelError( "Le template demandé est introuvable : $template" );
        }
        return $tpl;
    }
    private function checkBaseTemplate( String $base ) {
        $tpl = join_paths([TEMPLATES,$base.".php"]);
        if( !file_exists($tpl) ) {
            $tpl = join_paths([TEMPLATES,$base.".template.php"]);
            if( !file_exists($tpl) ) 
                throw new KernelError( "Le template de base demandé est introuvable : $base" );
        }
        return $tpl;
    }    

    private function processOutput( $file ) {
        $kParams = $this->templateParameters['parameters'];
        ob_start();
        include($file);
        $output = ob_get_contents();
        ob_end_clean();
        try {
            return $this->mustache->render($output, $this->templateParameters['parameters'] );
        }
        catch( Exception $e ) {
            throw new KernelError($e->getMessage());
        }
    }

    public function renderController() {
        echo $this->processOutput( $this->templateParameters['queryTemplate'] ); 
    }

    private function printOutput() {
        $count = 0;
        while( strpos($this->output,"{{") > -1 || strpos($this->output,"{%") > -1 ) {
            $count++;
            try {
                $this->processReplaces();
                $this->output = $this->mustache->render($this->output, $this->templateParameters['parameters'] );
            }
            catch( Exception $e ) {
                throw new KernelError($e->getMessage());
            }
            if( $count > 10 ) break;
        }
        echo $this->output;
        return $this;
    }

    public function apiError( String $msg ) {
        die(json_encode(core::apiError($msg)));
    }

    public function redirectToRoute( String $route, String $add = "" ) {
        die('<script>document.location.href="'.$this->route($route).$add.'";</script>');
    }

    public function route( String $routeName ) {
        $logoutRoutesNames = ['logout','logoff','disconnect','deconnexion'];
        if( in_array(strtolower($routeName),$logoutRoutesNames) )
            return URL.Logger::getSecurity()['logout']['url'];
        $newURL = Routes::getRouteFromName($routeName);
        if( $newURL === false )
            throw new KernelError("Aucune route nomée $routeName n'a été trouvée");
        return URL.substr($newURL,1);        
    }

    public function getImgLink( String $img ) {
        $path = path(ASSETS.'/img/'.$img);
        return file_exists($path) ? str_replace([APP_ROOT,"\\"],[URL,"/"],$path) : "#";
    }

    private function processReplaces() {
        global $Kernelite;
        $rule = "/\\{%(.*?)\\%}/si";
        preg_match_all($rule, $this->output, $tmp);
        if( !isset($tmp[1]) || empty($tmp[1]) ) return $this;
        foreach( $tmp[1] as $keyReplace => $raw ) {
            $raw = trim($raw);
            $pos = strpos($raw,"(");
            $posEnd = strpos($raw,")");
            if( $pos < 0 || $posEnd < 0 ) continue;
            $func = trim(substr($raw,0,$pos));
            $arg = trim(substr($raw,$pos+1,($posEnd-$pos-1)));

            // Trim des args
            $_trimTmpArgs = explode(",",$arg);
            if( count($_trimTmpArgs) > 1 ) {
                foreach( $_trimTmpArgs as $k => $e ) $_trimTmpArgs[$k] = trim($e);
                $arg = implode(",",$_trimTmpArgs);
            }

            switch( $func ) {
                case 'r' :
                case 'route' : {
                    $replaceWith = $this->route($arg);
                    break;
                }
                case 'asset' : {
                    $assetPath = path(ASSETS."/".$arg);
                    $replaceWith = file_exists($assetPath) ? urlize($assetPath) : '#';
                    break;
                }                
                case 'form' : {
                    $replaceWith = Structure::getForm($arg);
                    break;
                } 
                case 'fw' :
                case 'form_widget' : {
                    $tmpWidget = explode(",",$arg);
                    $replaceWith = Structure::getForm( $tmpWidget[0], $tmpWidget[1], $tmpWidget[2] ?? "" );
                    break;
                }                     
                case 'get' : {
                    list( $struc, $id, $field ) = explode(",",$arg);
                    if( !isset($field) || $field == "" ) $field = 'libelle';
                    $replaceWith = $Kernelite->dm->find($struc,$id)->getRow()[$field];
                    break;
                }
                case 'options' : {
                    $options = $Kernelite->dm->findAll($arg)->getByField('id','libelle');
                    array_unshift($options, "");
                    foreach($options as $k=>$e) $options[$k] = '<option value="'.$k.'">'.$e.'</option>';
                    $replaceWith = implode($options);
                    break;
                }
                case 'table' : {
                    $t_tmp = explode(",",$arg);
                    $t_datas = $t_tmp[0];
                    $t_id = $t_tmp[1] ?? false;
                    $t_headers = $t_tmp[2] ?? [];
                    if( !isset($this->templateParameters['parameters'][$t_datas]) )
                        err("La méthode {% $func %} n'a pas trouvé de tableau $t_datas dans vos paramètres de templates");
                    if( !empty($t_headers) && !isset($this->templateParameters['parameters'][$t_headers]) )
                        err("La méthode {% $func($arg) %} n'a pas trouvé de headers $t_headers dans vos paramètres de templates");
                    
                    if( !empty($t_headers) ) 
                        $t_headers = $this->templateParameters['parameters'][$t_headers];

                    $replaceWith = core::arrayToHtmlTable(
                        $this->templateParameters['parameters'][$t_datas],
                        $t_id,
                        $t_headers
                    );
                    break;
                }
                case 'btn' : {
                    $t_tmp = explode(",",$arg);
                    $t_libelle = $t_tmp[0];
                    $t_id = $t_tmp[1] ?? "";
                    $t_classes = $t_tmp[2] ?? "btn-success";
                    $t_attributes = $t_tmp[3] ?? "";
                    $replaceWith = '<button type="submit" class="btn '.$t_classes.'" id="'.$t_id.'" '.$t_attributes.' >'.$t_libelle.'</button>';
                    break;
                }
                case 'frag' :
                case 'fragment' : {
                    $path = join_paths([FRAGMENTS,strval($arg).'.php']);
                    if( !file_exists($path) ) 
                        err("Le fragment $arg n'a pas été trouvé : $path");
                    ob_start();
                    include($path);
                    $replaceWith = ob_get_contents();
                    ob_end_clean();
                    break;
                }
                case 'date_fr' : {
                    if( trim($arg) == "" ) {
                        $replaceWith = $arg;
                        break;
                    }
                    $k_tmp = explode(" ",$arg);
                    $k_date = $k_tmp[0];
                    if( strpos($k_date,"-") < 4 ) {
                        $replaceWith = $arg;
                        break;
                    }
                    $k_heure = $k_tmp[1] ?? false;
                    if( $k_heure ) 
                        $replaceWith = date("d/m/Y \à G\hi",strtotime($arg));
                    else 
                        $replaceWith = date("d/m/Y",strtotime($arg));
                    break;
                }
                case 'dd' :
                    $exposeAndDie = true;
                case 'd' : {
                    if( trim($arg) == "" ) {
                        $replaceWith = d($this->templateParameters['parameters'],true);
                    }
                    else {
                        $k_tmp = explode(",",$arg);
                        $rw = [];
                        foreach( $k_tmp as $ka ) {
                            $ka = trim($ka);
                            if( array_key_exists($ka,$this->templateParameters['parameters']) ) 
                                $rw[] = d($this->templateParameters['parameters'][$ka],true,["file" =>$this->templateParameters['queryTemplate']],);
                        }
                        $replaceWith = implode($rw);
                    }
                    if( isset($exposeAndDie) && $exposeAndDie == true ) {
                        echo $replaceWith;
                        die();
                    }
                        
                    break;
                }

                default :
                    throw new KernelError("La méthode {% $func %} de votre template n'est pas reconnue.");
            }
            $this->output = str_replace( $tmp[0][$keyReplace], $replaceWith, $this->output);  
        }
        return $this;
    }

    private function appendBodyDatas() {
        if( empty($this->bodyDatas) ) return;
        $findMe = "</body>";
        $bodyPos = strrpos($this->output, $findMe);
        if( !$bodyPos ) {
            d($this->output);
            throw new KernelError("Problème de fermeture de tags/balises.<br/>Impossible de trouver la fin du [/body]");
        }       
        $subStart = substr( $this->output, 0, $bodyPos );
        $subEnd = substr( $this->output, $bodyPos );
        $this->output = $subStart . implode($this->bodyDatas) . $subEnd;
        return;
    }

    private function appendKernelite() {
        $bodyAppendFiles = [
            join_paths([KERNELITE,'templates','kernelite-loader.php'] ),
            join_paths([KERNELITE,'templates','kernelite-layer.php'] )
        ];
        $append = [];
        foreach( $bodyAppendFiles as $file ) {
            if( !file_exists($file) || !is_readable($file) ) continue;
            ob_start();
            include( $file );
            $append[] = ob_get_contents();
            ob_end_clean();
        }
        $this->bodyDatas[] = implode($append);
        return $this;
    }

    public function loadPlugins( $plugins ) {
        if( empty($plugins) ) return $this;
        
        $files = [];
        foreach( $plugins as $file ) {

            # DS replace
            $tmp = explode( strpos($file,"/") > - 1 ? "/" : "\\" ,$file);
            $file = implode(DS,$tmp);

            # File exist ?
            $fullpath = join_paths([PLUGINS,$file]);
            if( !file_exists($fullpath) )
                err("Injection de plugins échouée, le fichier n'existe pas : $fullpath");

            $link = str_replace( [APP_ROOT,"\\"],[URL,"/"],$fullpath).CSTR;
            
            switch( strtolower(pathinfo($fullpath, PATHINFO_EXTENSION)) ) {
                case 'js' : {
                    $files[] = '<script src="'.$link.'" defer></script>';
                    break;
                }
                case 'css' : {
                    $files[] = '<link rel="stylesheet" href="'.$link.'">';
                    break;
                }   
                default : {
                    err("Injection de plugins échouée, ce type d'extension n'est pas reconnu : $fullpath");
                }             
            }
        }
        if( !empty($files) ) $this->bodyDatas[] = implode($files);
        return $this;
    }

    public function apiModeLandingPage() {
        if( !API_ONLY ) return;
        if( isset($this->req->route['url']) && $this->req->route['url'] != "" ) {
            $this->api404( $this->req->route['url'] );
        }

        $path = path(KERNELITE."/templates/kernelite-api-landing.php");
        if( !file_exists($path) ) dd($path." introuvable");
        include($path);
        exit;
    }

    public static function api404( String $route = "" ) {
        http_response_code(404);
        die(json_encode(["error"=>"true","errorMessage"=>"Route not found : $route"]));
    }










    /* Utilitaires */

    # Retourne un ou les parametres du template
    public function getParams( $key = null ) {
        return $this->templateParameters['parameters'][$key] ?? $this->templateParameters['parameters'];
    }

    # Retourne le dernier élément splited
    public function getLastURIParam() {
        $pos = count($this->uri) - 1;
        return $this->uri[$pos];
    }

    # Retourne le nieme élément splited
    public function getURIParam( Int $position = 0 ) {
        if( !isset($this->uri) || empty($this->uri) )
            return null;
        $default = count($this->uri) - 1;
        return $this->uri[$position] ?? $this->uri[$default];
    } 
    
    # Retourne le slug en fin d'URL (int)
    public function getSlug(  ) {
        $p = $this->getLastURIParam();
        return intval($p) == $p ? intval($p) : null;
    }

}