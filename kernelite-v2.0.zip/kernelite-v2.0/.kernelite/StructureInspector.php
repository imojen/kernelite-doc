<?php

class StructureInspector {

    public static function error( $msg ) {
        $msg = 'Erreur dans la définition d\'une structure .kernelite<br/>'.$msg;
        throw new KernelError($msg);
    }
    public static function dataerror( $msg ) {
        $msg = 'Erreur dans la définition des datas d\'une structure .kernelite<br/>'.$msg;
        throw new KernelError($msg);
    }


    public static function checkStructureIntegrity( String $strucName, $structure ) {

        if( !is_array($structure) )
            self::error("La structure <u>$strucName</u> est érronée ou vide");

        $allowedPropNames = [
            "is","type","label","options","check",
            "min", "max","default","match","required",
            "rules","suggest", "hash", "hide", "index",
            "class"
        ];

        foreach( $structure as $name => $props ) {
            if( !is_array($props) )
                self::error("Structure : $strucName.yaml<br/>Définition du champ : ".$name."<br/>Array attendu, mais ".gettype($props)." recu");
            
            $allow = ['_'];
            if( !ctype_alnum( str_replace($allow, '', $name ) ) )
                self::error("Structure : $strucName.yaml<br/>Définition du champ : ".$name."<br/>Les caractères autorisés pour les noms de champs sont : lettres, chiffres, tiret du bas");


            foreach( $props as $propName => $propValue ) {
                if( !in_array($propName,$allowedPropNames) ) 
                    self::error("Check structure | [$strucName] propriété [$propName] inconnue");

                $err = "Check structure | [$strucName] propriété [$propName] : valeur incorrecte";
                switch( $propName ) {
                    case 'is' : {
                        $allow = [NULL,"int","integer","float","double","string","boolean","date","text"];
                        if( !in_array($propValue,$allow) ) throw new KernelError($err);
                        break;
                    }
                    case 'suggest' : {
                        if( !is_array($propValue) ) throw new KernelError($err);
                        if( !isset($propValue['structure']) ) throw new KernelError($err);
                        break;
                    }
                }
            }
        }

        return true;
    }


    public static function datasChecker( String $name, Array $structure, $datas ) {
        $d = [];
        if( isset($datas['datas']) ) $d = $datas['datas'];
        else if( isset($datas[$name]) ) $d = $datas[$name];

        /* Permettre d'injecter les champs par defaut */
        $kFields = ["id","date_creation","date_modification","deleted"];
        foreach( $kFields as $e ) if( !in_array($e,$structure) ) $structure[$e] = [];
    

        if( empty($d) || !is_array($d) )
            self::dataerror("Impossible de charger les datas de $name.yaml");

        foreach( $d as $k=>$e ) {
            if( !is_array($e) || !is_int($k) )
                self::dataerror("Structure du fichier incorrecte : .structures/datas/$name.yaml ($k : ".gettype($k).")");

            foreach( $e as $field => $value ) {

                if( !in_array($field,array_keys($structure))  )
                    self::dataerror("Propriété [$field] inconnue dans la structure [$name]");


                if( !is_string($value) && !is_int($value) && !is_double($value) && !is_bool($value) )
                    self::dataerror("Valeur incorrecte (".gettype($value).") de la propriété [$field] de la strucutre [$name] (Element #".($k+1).", valeur : [$value])");

            }
        }

        return $d;
    }

}