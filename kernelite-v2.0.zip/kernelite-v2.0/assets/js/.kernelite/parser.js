// Params
$(function() {
    kernelite.params.init();
})

// Datepicker
$(function() {
    kernelite.fireEvent('datepicker')
});

// Attribution des valeurs des selects générés par form()
$(function() {
    $('select').each(function() {
        let v = $(this).attr('data-kernelite-value');
        if( kernelite.isNull(v) ) 
            v = $(this).attr('data-kernelite-default');
        if( !kernelite.isNull(v) )
            $(this).find('option[value="'+v+'"]').prop('selected',true);
    })
})

// Tooltip bootstrap
$(function() {
    kernelite.tooltips();
});

// Suggest
const kerneliteSuggestApi = URL+'kernelite/suggestApi/';
$(function() {
    $('input[data-kernelite-suggest]').each(function() {
        let temp = $(this).attr('data-kernelite-suggest').split("|"),
            struc = temp[0],
            id = $(this).attr('id'),
            idFieldName = temp[1],
            idField = kernelite.isNull(idFieldName) ? [] : $("#"+idFieldName),
            filters = temp[2].split(';'),
            cb = $(this).attr('data-kernelite-suggest-callback');



        $(this).autocomplete({
            source: '',
            minLength: 2,
            select: function( event, ui ) {
                let id = ui.item.id;
                if( idField.length == 1 ) idField.val(id)
                if( typeof eval(cb) === "function" ) eval(cb)(event,ui);
            },
            search : function() {
                if( idField.length == 1 ) idField.val('')
                let f = filters.map(val => {
                    let v = val.split(':');
                    return v[0] ? v[0]+"="+( $("#"+v[1]).length == 1 ? $("#"+v[1]).val() : v[1] ) : null;
                });          
                s = kerneliteSuggestApi+struc+'/filters:'+f.join('&')+'/';
                $(this).autocomplete('option','source',  s );
            }
        });
    })
});