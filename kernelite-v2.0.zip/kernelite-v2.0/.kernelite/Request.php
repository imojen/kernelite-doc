<?php
#[AllowDynamicProperties]
class Request {

    public $request;
    
    public function __construct( $request ) {
        $this->request = $request;
        foreach( $request as $k=>$e )
            $this->{$k}  = $e;
    }

    public function get( $prop ) {
        return $this->{$prop};
    }

    public function keys() {
        return array_keys($this->request);
    }

}