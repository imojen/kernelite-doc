<?php

global $DaemonRegistration;
$DaemonRegistration = [];

class Daemon {

    public $args;
    public $options;
    public $verbose;
    public $enable;
    public $dir;
    public $files;
    public $daemons;
    public $only;
    public $minutes;
    public $heures;
    public $updateMode;

    public function __construct( $args ) {
        $this->verbose = false;
        $this->updateMode = false;
        $this->enable = false;
        $this->only = false;
        $this->minutes = false;
        $this->heures = false;
        $this->args = $args;
        $this->initArgs();
        if( $this->updateMode ) {
            return $this->kerneliteUpdate();
        }
        $this->log("\r\n=====[.kernlite Daemon]=====\r\n","important");
        if( $this->only )
            $this->log("◼ Demande d'execution unique du daemon : ".$this->only."\r\n","success");
        $this->checkDaemons();
        if( !$this->enable ) return $this->end();
        $this->log( "Fin d'analyse : ".count($this->files)." fichier(s) de daemon(s) détécté(s).\r\n","info");
        $this->readDaemons();
        if( empty($this->daemons) ) return $this->end();
        if( $this->only && !$this->findOnly() ) return $this->end();
        $this->executeDaemons();
        $this->end();
    }

    public function getColor( $type ) {
        switch( $type ) {
            case "info" : return "\e[96m";
            case "error" : return "\e[91m";
            case "success" : return "\e[32m";
            case "important" : return "\e[93m";
            case "secondary" : return "\e[34m";
            default : 
                return "\e[39m";
        }
    }
    public function getTimingString( String $timing ) {
        $this->minutes = false;
        $this->heures = false;
        if( strpos($timing,"m/") > -1 ) {
            $tmp = explode("/",$timing);
            $this->minutes = intval($tmp[1]);
            return 'Toutes les '.$this->minutes.' minutes';
        }
        if( strpos($timing,"h/") > -1 ) {
            $tmp = explode("/",$timing);
            $this->heures = intval($tmp[1]);
            return 'Toutes les '.$this->heures.' heures';
        }        
        switch( $timing ) {
            case '*' : return 'Toutes les minutes de chaque heures';
            case 'hourly' : return 'Toutes les heures à la minute zéro';
            case 'daily' : return 'Une fois par jour à 00h00';
            default : return 'Timing non reconnu';
        }
    }

    public function log( $msg="", $type = "default" ) {
        if( !$this->verbose ) return $this;
        $color = $this->getColor($type);
        echo "".$color.$msg."\r\n\e[0m";
        return $this;
    }
    public function end() {
        $this->log("\r\n=====[.kernlite /Daemon]====\r\n","important");
    }

    public function initArgs() {
        if( empty($this->args) ) 
            crashError("Veuillez indiquer des arguments");
        foreach( $this->args as $arg ) {
            switch( $arg ) {
                case '--verbose' :
                    $this->verbose = true;
                    break;
            }
            if( strpos($arg,"--only") > -1 ) {
                $this->only = trim(str_replace("--only:","",$arg));
                continue;
            }
            if( strpos($arg,"--update") > -1 ) {
                $this->updateMode = true;
                continue;
            }
        }
        return $this;
    }

    public function checkDaemons() {
        $this->dir = path( kRoot().".daemons".DS );
        $this->log("Analyse du dossier : ".$this->dir,"info");
        if( !is_dir($this->dir) ) 
            return $this->log("Le dossier n'existe pas.","info");
        $this->files = core::getFilesFromDir($this->dir);
        if( empty($this->files) ) 
            return $this->log("Le dossier est vide.","info");
        $this->enable = true;
        return;
    }

    public static function register( String $name, String $timing, Callable $func ) {
        global $DaemonRegistration;
        $DaemonRegistration[] = [
            "name" => $name,
            "timing" => $timing,
            "function" => $func
        ];
        return;
    }

    public function readDaemons() {
        $this->log("\r\n🔰 Lecture des fichiers...\r\n","info");
        global $DaemonRegistration;
        $exist = [];
        foreach($this->files as $file) {
            $path = path($this->dir.$file);
            $diff = count($DaemonRegistration);
            include($path);
            $this->log("\t» $file : ".(count($DaemonRegistration)-$diff)." daemon(s) ajouté(s)","success");
            $daemonsNames = [];
            foreach($DaemonRegistration as $k=>$e) {
                if( in_array($k,$exist) ) continue;
                $daemonsNames[] = "\t\t◊ ".$e['name'].' : '.$this->getTimingString($e['timing']);
                $exist[] = $k;
            }
            if( !empty($daemonsNames) ) 
                $this->log(implode($daemonsNames)."\r\n","info");
        }
        $this->log("\r\n🔰 Tous les fichiers ont été lus : ".count($DaemonRegistration)." daemon(s) trouvé(s)\r\n","info");
        $this->daemons = $DaemonRegistration;
        return $this;
    }

    public function findOnly() {
        $exist = false;
        foreach( $this->daemons as $k=>$e ) {
            if( trim($e['name']) != $this->only ) {
                unset($this->daemons[$k]);
                continue;
            }
            else {
                $exist = true;
            }
        }
        if( !$exist ) {
            $this->log("Le daemon demandé n'a pas été trouvé : ".$this->only,"error");
            return false;
        }
        return $exist;
    }

    public function executeDaemons() {
        global $Kernelite;
        $this->log("\r\n🔰 Début de traitement des daemons ","info");
        $h = date('H');
        $m = date('i');
        foreach( $this->daemons as $d ) {
            $this->log("\r\n\t".$d['name']." : ".$this->getTimingString($d['timing']),"success");
            $do = true;
            if( $d['timing'] == "daily" && $h != "00" && $m != "00" ) $do = false;
            if( $d['timing'] == "hourly" && $m != "00" ) $do = false;
            if( $d['timing'] == "Timing non reconnu" ) $do = false;
            if( $this->minutes !== false && $m / $this->minutes != intval($m / $this->minutes) ) $do = false;
            if( $this->heures !== false && ( $m != "00" || ($h / $this->heures != intval($h / $this->heures)) ) ) $do = false;
            if( !$do && $d['name'] != $this->only) {
                $this->log("\t\tRien à faire à ce moment","success");
                continue;
            }
            else {
                $this->log("\t\t-- Début d'execution du daemon","success");
                $time_start = microtime(true);
                $log = call_user_func($d['function'],$Kernelite);
                $time_end = microtime(true);
                $delta = number_format($time_end - $time_start,2,","," ");
                if( is_array($log) ) {
                    foreach( $log as $line ) {
                        $this->log("\t\t\t# $line");
                    }
                }
                $this->log("\t\t-- Fin d'execution du daemon en $delta secondes","success");
            }
        }
        $this->log("\r\n🔰 Fin de traitement des daemons","info");
    }


    /* Update */
    public function kerneliteUpdate() {
        return new AutoUpdater();
    }

}