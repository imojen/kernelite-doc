<?php

class Kernelite {

    public Request $req;
    public Array $queryParameters = [];
    public Firewall $firewall;
    private Array $routes;
    public Routes $routeObj;
    private String $queryRoute;
    public Array $matchedRoute;
    private String $routeController;
    private String $routeFunction;
    public Bool $apiMode;
    private Array $dynamicParameters;
    private Bool $reflected;
    public Logger $logger;
    public DataManager $dm;
    public Bool $noRoute = false; 
    public $defaultRoute;

    public function __construct() {

        $this->defineGlobalKernelFunctions();

        # Initialisation du Firewall
        $this->firewall = new Firewall();  

        # Lecture des routes
        $this->getRoutes();

        # Datamanager
        if( DATAMANAGER )
            $this->dm = new DataManager();

        # Structures
        $this->loadStructures();

        # Initialisation de la Query
        if( !PHPCLI) $this->initQuery();
        
    }

    private function getRoutes() {
        $this->routeObj = new Routes();
        $this->routes = $this->routeObj->getRoutes();
        $this->defaultRoute = $this->routeObj->getDefaultRoute();
    }

    private function initQuery() {
        global $phpInput;
        $parsedInput = ( $phpInput != "" ? json_decode($phpInput, true) : [] );
        $splitedQuery = self::getSplitedParameters();
        $this->apiMode = false;
        if( count($splitedQuery) && strtolower($splitedQuery[0]) == "api") {
            array_shift($splitedQuery);
            $this->apiMode = true;
        }
        $this->queryParameters = [
            "queryString" => [
                "raw" => $_SERVER['QUERY_STRING'] ?? "",
                "value" => $_GET['QUERY_STRING'] ?? "",
                "empty" => ( trim($_GET['QUERY_STRING']) == "" ),
                "splited" => $splitedQuery,
                "parsed" => [implode("/",$splitedQuery)]
            ],
            "files" => $_FILES,
            "api" => $this->apiMode,
            "session" => $_SESSION,
            "route" => null,
            #"server" => $_SERVER,
            "input" => $parsedInput,
            "post" => empty($_POST) ? $parsedInput : $_POST,
        ];        
    }

    public static function getSplitedParameters() {
        return explode("/", $_GET['QUERY_STRING'] ?? "" );
    }

    private function getQueryRoute() {
        $tmp = $this->queryParameters['queryString']['parsed'];
        return array_shift($tmp);
    }

    public function processQuery( $query ) {
        $this->queryParameters = $query;

        # Définition de la route
        $this->queryRoute = "/".$this->getQueryRoute();

        $this->matchRouteFromQuery();
            

        # Logger
        $this->req = new Request($this->queryParameters);
        $this->logger = new Logger( $this->req, DATAMANAGER ? $this->dm : null );  

        if( API_ONLY ) 
            $this->internalApiRoutes();


        $this->logger
            ->checkLogout()
            ->checkConnected()
            ->checkLoginAttempt();


        # API interne
        if( strpos($this->queryRoute,'/kernelite/') > -1 ) {
            $this->apiMode = true;
            return $this->kernelApiCall();
        }



        # Sécurité
        $this
            ->checkRouteApi()
            ->checkRouteSecurity()
            ->checkFirewall();


        # Check login
        if( DATAMANAGER ) {
            //dd($this->matchedRoute);
            if( $this->logger->loginAttemptStatus && $this->isApiRoute( $this->matchedRoute )) {
                $this->apiResponse(["login"=>$this->logger->loginAttemptSuccess]);
            }
        }
        
        Events::emit('kernelite.beforeCall');

        # Définition du controller et de la méthode
        list( $this->routeController, $this->routeFunction ) = explode("::", $this->matchedRoute['controller']);
        $this
            ->checkCalledController()
            ->checkRoutePostDatas()
            ->processCall();
    }

    private function matchRouteFromQuery( $qRoute = null ) {
        if( $qRoute == null ) $qRoute = $this->queryRoute;


        foreach( $this->routes as $routeFile ) {
            foreach( $routeFile as $route ) {
                if( $route['url'] === $qRoute ) {
                    $this->matchedRoute = $route;
                    $this->queryParameters['route'] = $route;
                    return $this;
                }
            }
        }



        # Try shorter route
        $tmp = explode("/",$qRoute);
        array_pop($tmp);
        if( count($tmp) > 1 ) {
            return $this->matchRouteFromQuery( implode("/",$tmp) );
        }

        # Default
        $this->queryParameters['route']['url'] = $qRoute;
        return $this->setDefaultRoute();
    }

    private function setDefaultRoute() {
        $this->noRoute = true;
        $this->matchedRoute = $this->defaultRoute;
        return $this;
    }

    private function isApiRoute( $route ) {
        if( !isset($route['api']) ) return 0;
        return (boolean)$route['api'];
    }

    private function checkRouteApi() {
        $routeApiMode = $this->isApiRoute( $this->matchedRoute );

        if( !$this->queryParameters['api'] && $routeApiMode === true )
            throw new KernelError("Cette route n'est disponible que via API");

        if( $this->queryParameters['api'] && $routeApiMode === false )
            throw new KernelError("Cette route n'est pas disponible via API");


        return $this;
    }

    private function checkRouteSecurity() { 
        if( isset($this->matchedRoute['security']) ) {
            if( $this->matchedRoute['security'] == false ) return $this;
            if( !$this->logger->userMatchRule( $this->matchedRoute['security'] ) ) {
                if( !$this->logger->securityRedirect( new Controller(), $this->matchedRoute) )
                    throw new KernelError("Vous n'avez pas le droit d'accéder à cette page");
            }
        }
        return $this;
    }
    private function checkFirewall() {
        if( isset($this->matchedRoute['security']) ) return $this;
        if( !$this->firewall->isEnabled() ) return $this;
        if( isset($this->matchedRoute['default']) && $this->matchedRoute['default'] == true ) return $this;
        $match = $this->firewall->getMatch( $this->matchedRoute['url'] );
        if( $match == false ) return $this;
        foreach( $match['rules'] as $rule ) {
            if( !$this->logger->userMatchRule($rule) ) {
                if( !$this->firewall->redirect )
                    throw new KernelError("Vous n'avez pas le droit d'accéder à cette page");
                $c = new Controller();
                if( $this->firewall->policiesRedirection && isset($match['redirect']) ) 
                    return $c->redirectToRoute($match['redirect']);
                $c->redirectToRoute( $this->routeObj->getDefaultRoute()['name'] );
            }
        }
        return $this;
    }

    private function checkCalledController() {
        if( !class_exists($this->routeController) ) {
            throw new KernelError("Le controller de cette route n'existe pas : $this->routeController");
        }
        if( !method_exists($this->routeController,$this->routeFunction) ) {
            throw new KernelError("La méthode appelée de ce controller n'existe pas : $this->routeController::$this->routeFunction");
        }
        return $this;
    }

    private function checkRoutePostDatas() {
        if( !isset($this->matchedRoute['params']) ) return $this;
        $keys = array_keys($this->matchedRoute['params']);
        $postKeys = array_keys($this->queryParameters['post']);
        foreach( $keys as $key ) {
            if( !in_array($key,$postKeys ) )
                throw new KernelError("L'un des parametres est manquant pour cet appel ($key)");
            $types = explode(",",$this->matchedRoute['params'][$key]);
            $paramType = gettype($this->queryParameters['post'][$key]);
            if( in_array("int",$types) ) $types[] = "integer";
            if( !in_array($paramType,$types) ) {

                $box = "<strong>L'un des paramètres de cet appel n'a pas le bon type</strong>";
                if( ENV == "DEV" ) {
                    $box .= '<div class="alert alert-warning text-start mt-5" role="alert">';
                    $box .= 'Param name : '.$key.'<br/>';
                    $box .= 'Param type  : '.$paramType.'<br/>';
                    $box .= 'Expected type(s) : '.$this->matchedRoute['params'][$key].'</div>';
                }

                throw new KernelError($box);    
            }
        }
        return $this;
    }

    private function processCall() {

        $this->dynamicParameters = $this->queryParameters['post'];
        $this->reflectParameters(); 
        try {             
            $obj = new $this->routeController( $this->dynamicParameters );   
            if( $this->reflected )
                $response = call_user_func_array(array($obj, $this->routeFunction), $this->dynamicParameters);
            else
                $response = $obj->{$this->routeFunction}($this->dynamicParameters);
        } catch( Exception $e ) {
            throw new KernelError( $e->getMessage());
        }
        
        if(  $this->apiMode || API_ONLY ) 
            $this->apiResponse($response);
        
        return $this;
    }

    private function reflectParameters() {
        try {
            $this->reflected = false;
            $keys = array_keys($this->queryParameters['post']);
            $reflection = new ReflectionMethod($this->routeController, $this->routeFunction);
            $functionParameters = $reflection->getParameters();
            if( count($functionParameters) ) {
                $this->dynamicParameters = [];
                $this->reflected = true;
                foreach ( $functionParameters as $i=>$param) {
                    $name = $param->getName();
                    $p = new ReflectionParameter([$this->routeController, $this->routeFunction],$i);
                    $type = $p->getType()->getName();
                    $hasDefaultValue = $p->isDefaultValueAvailable();
                    
                    if( !$hasDefaultValue && !in_array($name,$keys) ) {
                        
                        if( class_exists($type) ) {
                            if( $type === "DataManager" ) $value = $this->dm;
                            elseif( $type === "Request" ) $value = $this->req;
                            elseif( $type === "Logger" ) $value = $this->logger;                           
                            else {
                                $value = new $type();
                                if( is_subclass_of($value,'Entity') ) 
                                    $value->__init(); // __init() method of abstract Entity 
                            }
                            $this->dynamicParameters[$i] = $value;
                            continue;
                        }
                        else 
                            throw new KernelError("Le parmetre $name est obligatoire pour l'appel de ".$this->routeFunction);
                    }
                    
                    $paramValue = (  in_array($name,$keys) ? $this->queryParameters['post'][$name] : $p->getDefaultValue() );
                    if( isset( $this->matchedRoute['params'][$name]) ) {
                        $xtmp = explode(",",$this->matchedRoute['params'][$name]);
                        $firsttype = array_shift($xtmp);
                        if( in_array($firsttype,['double','float','decimal']) )
                            $firsttype = "float";
                        settype($paramValue, $firsttype);      
                    }
                    $this->dynamicParameters[$i] = $paramValue;
                    
                }
            }
        } catch( Exception $e ) {
            throw new KernelError($e->getMessage());
        }
    }


    public function getRouteFunctionName() {
        return ucWords(strtolower($this->routeFunction));
    }

    public function defineGlobalKernelFunctions() {
        $functions = new Functions();
        $functions->initSuperGlobals();
        return $this;
    }

    public function apiResponse( $datas ) {
        if( !is_array($datas) ) 
            $datas = [ "response" => $datas ];
        if( !isset($datas['success']) )
            $datas['success'] = true;
        die( json_encode($datas,JSON_FORCE_OBJECT) );
    }

    private function loadStructures() {
        if( !DATAMANAGER ) return $this;
        Structure::_load( $this->dm );
        return $this;
    }

    private function kernelApiCall() {
        if( !isset($this->queryParameters['queryString']['splited'][1]) )
            throw new KernelError("Aucun parametre reçu");
        switch( $this->queryParameters['queryString']['splited'][1] ) {
            case 'asyncFileUpload': {
                $fm = new FileManager();
                $fm->asyncFileUpload( $this->queryParameters['files'] );
                break;
            }
            case 'removeTmpDir' : {
                $fm = new FileManager();
                $fm->removeTmpDir( $this->queryParameters['post'] );
                break;                
            }
            case 'suggestApi' : {
                new Suggest( $this->dm, $this->logger, $this->queryParameters );
                break;
            }
            case 'isConnected' : {
                core::apiSuccess(["connected" => $this->logger->isConnected()]);
            }
            default : 
                throw new KernelError("Méthode inconnue pour l'appel kernel");                
        }
        return $this;
    }


    public function internalApiRoutes() {
        switch( $this->queryRoute ) {
            case '/k-Auth-v1' : 
                $this->logger->apiLogin();
            case '/checkTokenValidity' : 
                $this->logger->checkTokenValidity();
            default : {
                $this->logger->openApiSession();
            }
        }

        if( $this->noRoute )
            Controller::api404( $this->queryRoute );            

        return $this;
    }


}