<?php
class Index extends Controller {

    #@Route = { "url" : "/", "default" : true }
    public function home() {        
        $this->render('index/home',[
            "title" => "Bienvenue sur .kernelite"
        ]);
    }
    
    #@Route = { "url" : "/test" }
    public function test() {
        $this->render('index/test',[
            "title" => "Page de test",
            "date" => date('d/m/Y'),
            "heure" => date('G\hi\ms')
        ]);
    }
}