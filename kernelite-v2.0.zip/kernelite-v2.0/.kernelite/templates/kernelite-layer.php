<template  id="kernelite-layer-template" style="display: none">
    <swal-html></swal-html>
    <swal-param name="allowEscapeKey" value="false" />
</template>