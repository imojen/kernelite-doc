<?php
$userFile = path(TEMPLATES."/api.php");
if( file_exists($userFile) ) return include($userFile);
?>


<div style="text-align:center;font-size: 14px;font-family:Arial,sans-serif;max-width:500px;margin: 50px auto;">
    <img src="<?php echo URL;?>assets/css/vendor/images/kernelite-logo-m.png"/>
    <div class="alert alert-success mt-3">
        <i class="far fa-check-circle mb-3" style="font-size:50px"></i>
        <br/>
        Ce projet .kernelite est fonctionnel en mode API uniquement.<br/>
        <hr/>
        <p>
            Pour personnaliser cette page :<br/>
            Créer votre fichier <strong>api.php</strong> à la racine du dossier <em>.templates/</em>
        </p>
    </div>
</div>