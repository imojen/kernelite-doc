<?php

class core {

    public static function apiError( String $msg ) {
        return [
            "success" => false,
            "errorMessage" => $msg
        ];
    }
    public static function apiSuccess( Array $repsonse ) {
        if( !in_array("success",$repsonse) )
            $repsonse["success"] = true;
        die(json_encode($repsonse));
    } 
    
    public static function getTrace() {
        ob_start();
        debug_backtrace();
        $trace = ob_get_contents();
        ob_end_clean();
        return $trace;
    }

    public static function bufferIt( $eval ) {
        ob_start();
        try {
            eval( $eval );
        }
        catch( Error $e ) {
            err($e->getMessage());
        }
        $content = ob_get_contents();
        ob_end_clean();
        return $content;
    }

    public static function getFileName( $fullPath, $extention = true ) {
        $tmp = explode( DIRECTORY_SEPARATOR, $fullPath );
        $fileName = array_pop($tmp);
        if( $extention ) return $fileName;
        $tmp = explode(".",$fileName);
        $ext = array_pop($tmp);
        return basename($fileName,".".$ext);
    }

    public static function getFilesFromDir( $dir ) {
        $files = array_diff(scandir($dir),[".",".."]);
        foreach( $files as $k=>$file ) {
            if( is_dir(join_paths([$dir,$file])) )
                unset($files[$k]);
        }
        return $files;
    }

    public static function salt( $string, $salt = null, $sens = 1 ) {
        if( !$salt ) $salt = DB_SALT;
        switch( intval($sens) ) {
            case 1 : return md5($salt.$string);
            case 2 : return md5($string.$salt);
            case 3 : return md5($salt.$string.$salt);
            default :  return md5($string);
        }
    }

    public static function minMaxLength( String $str, Int $min, Int $max ) {
        return mb_strlen($str) >= $min && mb_strlen($str) <= $max;
    }

    public static function dateOutput( String $date, $full = false ) {
        return date('d/m/Y'.($full? ' \à G\hi' : ''), strtotime($date));
    }
    public static function dateInput( String $date ) {
        return date('Y-m-d', strtotime($date));
    }

    public static function dateCourte( String $date ) {
        $d =new datetime($date) ;
        return $d->format('Y-m-d');
    }
    
    public static function toDatesql( String $date ) {
        if( trim($date) == "" ) return $date;
        $tmp = explode(" ",$date);
        $tmp2 = explode("-", $tmp[0]);
        if( count($tmp2) != 3 ) return $date;
        return implode("/",array_reverse($tmp2));
    } 
    
    public static function toDatetime( String $date ) {
        if( trim($date) == "" ) return $date;
        $tmp = explode(" ",$date);
        $tmp2 = explode("/", $tmp[0]);
        if( count($tmp2) != 3 ) return $date;
        return implode("-",array_reverse($tmp2));
    }    

    

    public static function dateFrom($time) {
        if( $time == "" ) return 'Jamais';
        if( strpos($time,"-") > -1 )
            $time = strtotime($time);
        //d(date("G:i"));
        $time = time() - $time;
        $time = ($time<1)? 1 : $time;
        $tokens = [
            31536000 => 'an',
            2592000 => 'mois',
            604800 => 'semaine',
            86400 => 'jour',
            3600 => 'heure',
            60 => 'minute',
            1 => 'seconde'
        ];
        foreach ($tokens as $unit => $text) {
            if ($time < $unit) continue;
            $numberOfUnits = floor($time / $unit);
            return $numberOfUnits.' '.$text.(($numberOfUnits>1&&$text!="mois")?'s':'');
        }
    }    

    public static function mustacheIt( $it, $params ) {
        $mustache = new Mustache_Engine(array('entity_flags' => ENT_QUOTES));
        return $mustache->render($it, $params);
    }

    public static function isMailValid( String $email ) {
        $r = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/'; 
        return preg_match($r, $email);
    }

    public static function arrayToHtmlTable( Array $table = [], String $id = "", Array $headers = [] ) {
        if( empty($table) ) return "";

        $tmp = $table;
        $first = array_shift($tmp);
        $col_headers = array_keys($first);
    
        if( empty($headers) )
            $headers = $col_headers;

        $content = [];
        $content[] = '<table class="table" id="'.$id.'">';
        $content[] = '<thead><tr>';
        foreach( $headers as $h )
            $content[] = '<th scope="col">'.$h.'</th>';
        $content[] = '</tr></thead><tbody>';
        foreach( $table as $k=>$e ) {
            $content[] = '<tr>';
            foreach( $col_headers as $h )
                $content[] = '<td>'.$e[$h].'</td>';
            $content[] = '</tr>';
        }
        $content[] = '</tbody></table>';
        return implode($content);
    }

    public static function normalizePath( String $path ) {
        return function_exists('path') ? path($path) : str_replace(["/","\\"],DS,$path);
    }

    public static function generateString( $l = 5, $alpaOnly = false ) {
        $p = [];
        $a = $alpaOnly ? "ABCDEFGHIJKLMNOPQRSTUWXYZ" : "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
        for ($i = 0; $i < $l; $i++) $p[] = $a[rand(0, strlen($a) - 1)];
        return implode($p);
    }    

    public static function readableSize($bytes, $dec = 2) {
        $size   = array('B', 'kB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB');
        $factor = floor((strlen($bytes) - 1) / 3);
        return sprintf("%.{$dec}f", $bytes / pow(1024, $factor)) . ' ' . @$size[$factor];
    }
    

}