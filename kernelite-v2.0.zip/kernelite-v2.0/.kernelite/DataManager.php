<?php

global $DataManagerLogHistory;

class DataManager {

    private $link;
    private Array $structure;
    private Array $history;

    private String $sqlQuery;
    private $sqlResult;
    public Bool $successQuery;
    private Array $arrayResults;
    private Int $lastId;
    private String $errorMessage;

    private Array $caller;
    private $debugBacktrace;

    private Array $createdIds;
    private Array $numericFieldsTypes = ["int","double","float"];
    private Array $credentials;

    public String $salt = "";
    public Int $saltOrder = 1;

    private $mode;

    public function __construct( $baseName = '' ) {
        if( !DATAMANAGER ) return;
        global $kDatabases;

        $this->history = [];
        $this->structure = [];
        $this->arrayResults = [];

        if( $baseName == '' ) $baseName = 'main';
        if( !isset($kDatabases[$baseName]) )
            err("La base de données $baseName n'existe pas");
        $this->credentials = $kDatabases[$baseName];

        if( isset($this->credentials['passwords']) ) {
            if( isset($this->credentials['passwords']['salt']) )
                $this->salt = $this->credentials['passwords']['salt'];
            if( isset($this->credentials['passwords']['saltOrder']) )
                $this->saltOrder = intval($this->credentials['passwords']['saltOrder']);                
        }

        switch( $this->credentials['mode'] ) {
            case 'mysql' : {
                $this->mode = new mysqlObject($this->credentials);
                break;
            }
            case 'sql-server' : {
                $this->mode = new sqlObject($this->credentials);
                break;
            }  
            default :
                crashError("La valeur de <strong>bdd_mode</strong> de la base <strong>$baseName</strong> n'est pas reconnue");          
        }


        $this
            ->createConnection()
            ->setStructure();

    }

    public function isMainDatabase() {
        return $this->credentials['name'] == "main";
    }

    private function createConnection() {
		$this->link = $this->mode->createConnection();        
        return $this;
    }

    public static function history() {
        global $DataManagerLogHistory;
        return $DataManagerLogHistory;
    }

	public function query( String $sqlQuery, Bool $logQuery = true ) {

        $this->arrayResults = [];        

		$this->sqlQuery = $sqlQuery;
        $this->sqlResult = $this->mode->query( $this->link, $sqlQuery );
        $this->successQuery = ($this->sqlResult !== false);
        $this->errorMessage = $this->mode->getError();
        if( ENV == "DEV" ) {
            $this->debugBacktrace = debug_backtrace();
            $this->caller = [];
            foreach( $this->debugBacktrace as $k=>$e)  {
                $name = $e["function"];
                if( isset($e['class']) )
                    $name = $e['class'].'::'.$name;
                $this->caller[] = $name;
            }
            if( $logQuery) {
                global $DataManagerLogHistory;
                $this->history[] = [
                    "query" => $this->sqlQuery,
                    "callerStack" => $this->caller,
                    "success" => $this->successQuery,
                    "error" => $this->errorMessage
                ];
                $DataManagerLogHistory = $this->history;
            }
        }

        if( !$this->successQuery )
            throw new KernelError("DataManager : Erreur SQL<br/>".$this->errorMessage);

        if( strpos(strtolower($this->sqlQuery),"insert") )
            $this->lastId = $this->mode->getLastId();

		return $this;
	}

    public function getQuery() {
        return $this->sqlQuery;
    }

    public function get( $field = "" ) {
        if( !$this->successQuery ) return;
        while( $r = $this->mode->assoc( $this->sqlResult ) ) 
            $this->arrayResults[] = $r;
        if( $field != "" && count($this->arrayResults) == 1 ) {
            $line = $this->arrayResults[0];
            if( array_key_exists($field, $line) )
                return $line[$field];
        }
        return $this->arrayResults;
    }

    public function getRow() {
        if( !$this->successQuery ) 
            throw new KernelError("Aucune ligne à retourner");
        return $this->mode->assoc( $this->sqlResult );
    }

    public function getByField( String $field = "id", String $fieldValue = "" ) {
        if( !$this->successQuery ) return;
        while( $r = $this->mode->assoc( $this->sqlResult ) ) {
            if( !isset($r[$field]) )
                throw new KernelError("Le résultat de la requête ne comprend pas de champ $field la séléction par champ");
            $this->arrayResults[$r[$field]] = ($fieldValue == "" || !isset($r[$fieldValue]) ? $r : $r[$fieldValue]);
        }
        return $this->arrayResults;        
    }

    public function getOneField( String $field ) {
        if( !$this->successQuery ) return;
        while( $r = $this->mode->assoc( $this->sqlResult ) ) {
            if( !isset($r[$field]) )
                throw new KernelError("Le résultat de la requête ne comprend pas de champ $field la séléction par champ unique");
            $this->arrayResults[] = $r[$field];
        }
        return $this->arrayResults;        
    }    

    public function getLastId() {
        return (int)$this->lastId;
    }

    public function count() {
        return $this->mode->count( $this->sqlResult );
    }
    public function getRowResult() {
        if( !$this->successQuery ) return;
        
        while( $r = $this->mode->rows( $this->sqlResult ) ) {
            $this->arrayResults[] = $r;
        }
        return $this->arrayResults;          
    }

    public function escape( String $str ) {
        return $this->mode->escape( $str );
    }


    public function setStructure() {
        $this->structure = [
            "TABLES" => $this->defineTables(),
            "TABLES_STRUC" => []
        ];
        foreach(  $this->structure['TABLES'] as $table ) 
            $this->structure['TABLES_STRUC'][$table] = $this->defineTableFields($table);

        return $this;
    }

    private function defineTables() {
        return $this->query( $this->mode->defineTables , false)->getOneField('TABLE_NAME');
    }

	private function defineTableFields( String $table ) {

		return $this->query($this->mode->defineTablesFields($table), false)->getByField('name');
	} 
    
    public function getTables() {
        return $this->structure['TABLES'];
    }

    public function getTableFields( String $table ) {
        if( !in_array($table,$this->structure['TABLES']) )
            throw new KernelError("La table $table n'existe pas");
        return $this->structure['TABLES_STRUC'][$table];
    }   
    
    private function checkTable( String $table ) {
        if( !in_array($table,$this->structure['TABLES']) )
            throw new KernelError("La table $table n'existe pas dans la base ".DB_NAME);
    }

    private function checkField( String $field, String $table = null ) {
        if( $table == null && ( isset($this->currentTable) && !$this->currentTable) )
            throw new KernelError("Aucune table fourni pour tester l'existance du champ");
        if( $table == null )
            $table = $this->currentTable;
        $this->checkTable($table);
        if( !array_key_exists($field,$this->structure['TABLES_STRUC'][$table]) ) {
            return false;
        }
    }
    private function hasDeletedField( String $table = null ) {
        return $this->checkField( 'deleted', $table );
    }
    private function hasIdField( String $table = null ) {
        return $this->checkField( 'id', $table );
    }   



    # Manipulations 
    private String $currentTable;
    private String $currentId;
    private Array $currentObject = [];
    private Array $currentStructure = [];
    private Datas $object;
    public function use( String $table, Int $id ) {
        $this->checkTable($table);
        $query = "SELECT * FROM $table WHERE id = $id ".($this->hasDeletedField($table) ? ' AND deleted = 0 ' : '' );
        $this->query($query);
        if( !$this->successQuery || $this->count() == 0 )
            throw new KernelError("Impossible d'utiliser use car aucun résultat sur la séléction : $query");
        $this->object = new Datas();
        $this->currentTable = $table;
        $this->currentId = $id;
        $this->currentObject = $this->getRow();
        if( Structure::exists($table) )
            $this->currentStructure = Structure::get($table);
        foreach( $this->currentObject as $key => $value ) {
            $this->object->prop[$key] = $value;
        }
        return $this;
    }
    public function useFrom( String $table, String $field, $value ) {
        $this->checkField($field, $table);
        $query = "
            SELECT id FROM $table 
            WHERE 
                $field = '".$this->escape($value)."'
            LIMIT 1
        ";
        $id = $this->query($query)->getRow()['id'];
        return $this->use($table,$id);
    }
    public function refresh() {
        if( !$this->currentObject )
            throw new KernelError("Impossible d'utiliser refresh sans avoir au préalable appelé use");
        return $this->use($this->currentTable,$this->currentId);
    }
    public function getValue($field) {
        if( !$this->currentObject )
            throw new KernelError("Impossible d'utiliser getValue  sans avoir au préalable appelé use");
        if( !array_key_exists($field,$this->object->prop) ) {
            throw new KernelError("Le champ $field n'existe pas dans l'objet courant");
        }
        return $this->object->prop[$field];
    }
    public function getFields() {
        return array_keys($this->object->prop);
    }    
    public function getArray() {
        if( !$this->currentObject )
            throw new KernelError("Impossible d'utiliser getArray  sans avoir au préalable appelé use");        
        return $this->object->prop;
    }
    public function set( String $field, $value ) {
        if( !$this->currentObject )
            throw new KernelError("Impossible d'utiliser set sans avoir au préalable appelé use");
        if( $this->checkField($field) === false ) return $this;
        if( $this->currentStructure && isset($this->currentStructure[$field]) ) {
            if( isset($this->currentStructure[$field]['hash']) && $this->currentStructure[$field]['hash'] == true )
                $value = core::salt($value, $this->salt, $this->saltOrder);
        }
        

        $_db_value = $value === null ? 'NULL' : "'".$this->escape($value)."'";

        $query = "
            UPDATE
                ".$this->currentTable."
            SET
                $field = ".$_db_value."
            WHERE
                id = ".$this->currentId."
        ";
        $this->query($query);
        $this->object->prop[$field] = $value;
        return $this;
    }
    public function multiSet( Array $datas ) {
        foreach( $datas as $key=>$value ) {
            $this->set($key,$value);
        }
        return $this;
    }
    public function delete() {
        if( !$this->currentObject )
            throw new KernelError("Impossible d'utiliser delete sans avoir au préalable appelé <use>");        
            $query = "
            DELETE FROM
                ".$this->currentTable."
            WHERE
                id = ".$this->currentId."
        ";
        $this->query($query);
        return $this->off();
    }
    public function off() {
        $this->currentTable = "";
        $this->currentId = "";
        $this->currentObject = [];
        return $this;
    }


    # Insertion
    public function create( String $table, Mixed $datas = [], Bool $ignoreUnknown = true ) {
        $this->checkTable($table);

        if( gettype($datas) == "object" && get_class($datas) == "Post" )
            $datas = $datas->toArray();

        if( empty($datas) ) {
            global $Kernelite;
            if( isset($Kernelite->req->post) ) 
                $datas = $Kernelite->req->post;
            if( empty($datas) )
            throw new KernelError("Tentative de création dans $table sans données");
        }

        $tableFields = array_keys($this->getTableFields($table));

        $copy = $datas;
        $elem = array_pop($copy);
        if( !is_array($elem) ) {
            $datas = [$datas];
        }

        # Hash
        $hash = [];
        if( Structure::exists($table) ) {
            $s = Structure::get($table);
            foreach( $s as $field => $prop ) {
                if( isset($prop['hash']) && $prop['hash'] == true )
                   $hash[] = $field; 
            }
        }

        $this->createdIds = [];
        foreach( $datas as $row ) {
            $rowValues = [];
            $fields = [];
            foreach( $row as $field => $value ) {
                if( !in_array($field,$tableFields) ) {
                    if( !$ignoreUnknown )
                        throw new KernelError("Le champ $field n'existe pas dans la table $table");
                    continue;
                }
                $fields[] = ( DB_MODE == "mysql" ? '`'.$field.'`' : '['.$field.']' );

                if( in_array($field,$hash) )
                    $value = core::salt($value, $this->salt, $this->saltOrder);

                if( $value === null )
                    $rowValues[] = "NULL";
                else 
                    $rowValues[] = "'".mb_convert_encoding($this->escape(trim($value)),'UTF-8')."'";
            }
            if( empty($rowValues) )
                continue;
            $firstRow = false;
            $query = "
            INSERT INTO $table
            (".implode(",",$fields).")
            VALUES        
            (".implode(",",$rowValues).")
            ";         
            $this->query($query);
            $this->createdIds[] = $this->getLastId();
        }
        return $this;
    }

    public function getCreatedIds() {
        return $this->createdIds;
    }


    # Recherche
    public function find( String $table, Int $id ) {
        $this->checkTable($table);
        $query = "SELECT * FROM $table WHERE id = $id ".($this->hasDeletedField($table) ? ' AND deleted = 0 ' : '' );
        $this->query($query);
        return $this;
    }
    public function findAll( String $table, Array $params = []) {
        $this->checkTable($table);      
        $where = [];

        $operators = [
            "!" => "!=",
            "%" => "LIKE",
            ">" => ">",
            ">=" => ">=",
            "<" => "<",
            "<=" => "<=",
            "[]" => "IN",
            "][" => "BETWEEN ",
        ];



        if( isset($params['filters']) && !isset($params['filter']) )
            $params['filter'] = $params['filters'];
        if( isset($params['filter']) ) {
            foreach( $params['filter'] as $field => $value ) {

                $operator = "=";
                foreach( $operators as $k => $e ) {
                    if( strpos($field, $k) > -1 ) {
                        $operator = $e;
                        $field = str_replace($k,"",$field);
                        if( $operator == "LIKE" )
                            $value = '%'.$value.'%';
                    }
                }

                if( array_key_exists($field,$this->structure['TABLES_STRUC'][$table]) ) {
                    $type = $this->structure['TABLES_STRUC'][$table][$field]['type'];
                    if( $operator == "IN" && is_array($value) ) {
                        $tab = [];
                        foreach( $value as $e ) $tab[]= "'".$this->escape(strtolower($e))."'";
                        $where[$field] = ' LOWER(`'.$field."`) $operator (".implode(',',$tab).") ";
                        
                    }
                    else if( $operator == "BETWEEN " && is_array($value) && count($value) == 2 ) {
                        $min = "'".$this->escape(strtolower($value[0]))."'";
                        $max = "'".$this->escape(strtolower($value[1]))."'";
                        $where[$field] = " `".$field."` BETWEEN  $min AND $max ";
                    }
                    else if( in_array($type,$this->numericFieldsTypes) )
                        $where[$field] = ' `'.$field."` $operator ".$this->escape(strtolower($value))." ";
                    else 
                        $where[$field] = ' LOWER(`'.$field."`) $operator '".$this->escape(strtolower($value))."'";
                }
            }
        }
        if( !array_key_exists('deleted',$where) && $this->hasDeletedField($table) )
            $where['deleted'] = 0;
        $orderBy = "";
        if( isset($params['orderBy']) ) {
            if( !is_array($params['orderBy']) )
            $params['orderBy'] = [$params['orderBy']];
            foreach( $params['orderBy'] as $f ) $this->checkField($f,$table);
            $orderBy = $params['orderBy'];
            $order = "ASC";
            $order = isset($params['order']) && $params['order'] == "DESC" ? "DESC"  : "ASC";
        }
        $operator = isset($params['operator']) && $params['operator'] == "OR" ? "OR"  : "AND";
        $limit = isset($params['limit']) && intval($params['limit']) > 0 ? intval($params['limit']) : false;
        $offset = isset($params['offset']) && intval($params['offset']) > 0 ? intval($params['offset']) : false;

        $query = ["SELECT * FROM $table"];
        if( !empty($where) ) 
            $query[] = " WHERE ( ".implode(' '.$operator.' ',$where)." )";
        
        if( !empty($orderBy) )
            $query[] = "ORDER BY ".implode(",",$orderBy)." ".$order;
        
        if( $limit > 0 )
            $query[] = "LIMIT $limit";
        if( $offset > 0 )
            $query[] = "OFFSET $offset";


       return $this->query( implode(" ",$query));
    }

    public static function now() {
        return date('Y-m-d G:i:s');
    }

    public function reset( String $structure ) {
        $this->checkTable($structure);
        return $this->query("TRUNCATE TABLE $structure");
    }

}