<?php

class sqlObject {

    public $link;
    public $defineTables;
    public $credentials;


    public function __construct( $credentials = [] ) {
        $this->credentials = $credentials;
        if( empty($this->credentials) ) {
            $this->credentials = [
                "host" => DB_HOST,
                "user" => DB_USER,
                "password" => DB_PASS,
                "base" => DB_NAME
            ];
        }
        $this->defineTables = "
        SELECT 
            TABLE_NAME
        FROM 
            INFORMATION_SCHEMA.TABLES
        WHERE
            TABLE_CATALOG = '".$this->credentials['base']."' 
        ";       
    }

    public function createConnection() {
		$this->link = @sqlsrv_connect( $this->credentials['host'], [
            "Database"  => $this->credentials['base'], 
            "UID"       => $this->credentials['user'], 
            "PWD"       => $this->credentials['password']
        ]);
		if( !$this->link ) 
			crashError("Impossible de se connecter à la base de données");

		return $this->link;        
    }  

    public function query( $link, $sqlQuery ) {
        return sqlsrv_query( $link, $sqlQuery, [], ["Scrollable" => SQLSRV_CURSOR_KEYSET] );
    }

    public function getError() {
        $err = sqlsrv_errors();
        if( is_array($err) && isset($err[0]['message']) ) return utf8_encode($err[0]['message']);
        else {
            if( is_array($err) ) {
                d($err);
                $err = "Erreur SQL serveur survenue";
            }
        }
        return (string)$err;
    }   
    
    public function getLastId() {
        $q = sqlsrv_query($this->link,"SELECT SCOPE_IDENTITY() AS id");
        return sqlsrv_fetch_array( $q, SQLSRV_FETCH_ASSOC)['id'];
    }    

    public function assoc( $object ) {
        return sqlsrv_fetch_array( $object, SQLSRV_FETCH_ASSOC);
    }

    public function count( $object ) {
        return sqlsrv_num_rows( $object );
    }

    public function rows( $object ) {
        return sqlsrv_fetch($object);
    }  
    
    public function escape( $object ) {
        return str_replace("'", "''", $object );;
        /*if(is_numeric($object))
            return $object;
        $unpacked = unpack('H*hex', $object);
        return '0x' . $unpacked['hex'];*/
    }
    
    public function defineTablesFields( $table ) {
        return "
        SELECT 
            COLUMN_NAME as name ,DATA_TYPE as type,CHARACTER_MAXIMUM_LENGTH as max_length
        FROM 
            information_schema.COLUMNS 
        WHERE 
            TABLE_CATALOG = '".$this->credentials['base']."' 
            AND TABLE_NAME = '".$this->escape($table)."'
        ";
    }

}