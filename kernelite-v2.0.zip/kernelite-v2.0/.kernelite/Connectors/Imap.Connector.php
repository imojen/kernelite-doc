<?php

class Imap
{

    private $imapBox;
    private $imapCheck;
    private $inBox;
    private $virutalBox;

    private $imapString;
    private $imapUser;
    private $imapPassword;

    private $debug;

    public function __construct(String $imapString, String $imapUser, String $imapPassword, Bool $debug = false) {
        if (!function_exists('imap_open'))
            throw new KernelError("Veuillez activer le module IMAP sur le serveur");
        $this->imapString = $imapString;
        $this->imapUser = $imapUser;
        $this->imapPassword = $imapPassword;
        $this->debug = $debug;
        $this->openConnection();
    }

    private function openConnection() {
        if($this->debug) d("Tentative de connexion : "."{" . $this->imapString . "}INBOX");
        $this->imapBox = imap_open("{" . $this->imapString . "}INBOX", $this->imapUser, $this->imapPassword);
        if (!$this->imapBox)
            throw new KernelError(imap_errors());
        if($this->debug) d("Connexion ok, récupération des informations sur la boite...");
        $this->imapCheck = imap_check($this->imapBox);
        if($this->debug) d($this->imapCheck);
    }
    public function getImapInfos()
    {
        return $this->imapCheck; 
    }
    public function getMailBoxOverview()
    {
        $result = imap_fetch_overview($this->imapBox, "1:{$this->imapCheck->Nmsgs}", 0);
        $datas = [];
        foreach ($result as $overview) {
            $datas[] = [
                "msgno" => $overview->msgno,
                "date" => $overview->date,
                "from" => $overview->from,
                "subject" => $overview->subject,
            ];
        }
        return $datas;
    }

    public function getMailBox( String $flag = "ALL" ) {
        $this->fetchBox($flag);
        $this->parseBox();
        return $this->virutalBox;
    }


    private function fetchBox(String $flag) {
        $this->inBox = imap_search($this->imapBox, $flag);
        if( $this->inBox ) rsort($this->inBox);
        else $this->inBox = [];
    }
    private function parseBox() {
        $this->virutalBox = [];
        foreach ($this->inBox as $index) {
            $mail = [];
            $mail['header'] = $this->formatHeaderInfos( imap_headerinfo($this->imapBox, $index) );
            $struc = imap_fetchstructure($this->imapBox, $index);
            $mail['content'] = [];
            if (!isset($struc->parts) || !$struc->parts ) {
                $mail['content'] = $this->getpart($this->imapBox, $index, $struc, 0);
            } else { 
                foreach ($struc->parts as $part_n => $p) {
                    $mail['content'] = $this->getpart($this->imapBox, $index, $p, $part_n + 1);
                }
            }
            $this->virutalBox[] = $mail;
        }
    }

    public function getpart($mbox, $mid, $p, $part_n) {
        $content = [];
        $data = ($part_n) ? imap_fetchbody($mbox, $mid, $part_n) : imap_body($mbox, $mid);

        // Decode
        if ($p->encoding == 4) {
            $data = quoted_printable_decode($data);
        } else if ($p->encoding == 3) {
            $data = base64_decode($data);
        }

        $eparams = [];
        if ($p->parameters) 
            foreach ($p->parameters as $x) 
                $eparams[strtolower($x->attribute)] = $x->value;
            
        if (isset($p->dparameters)) 
            foreach ($p->dparameters as $x) 
                $eparams[strtolower($x->attribute)] = $x->value;
            
        $content['params'] = $eparams;

        $content['attachments'] = [];
        if (isset($eparams['filename']) || isset($eparams['name'])) {
            $filename = ( isset($eparams['filename']) ) ? $eparams['filename'] : $eparams['name'];
            $content['attachments'][$filename] = $data;
        }

        $content['plain'] = $content['html'] = $content['charset'] = "";
        if ($p->type == 0 && $data) {
            if (strtolower($p->subtype) == 'plain') 
                $content['plain'] .= trim($data) . "\n\n";
            else 
                $content['html'] .= $data . '<br><br>';
            $content['charset'] = $eparams['charset'];
        } 
        else if ($p->type == 2 && $data)
            $content['plain'] .= $data . "\n\n";
        

        $content['subparts'] = [];
        if (isset($p->parts)) {
            foreach ($p->parts as $part_n2 => $p2) {
                $content['subparts'][] = $this->getpart($mbox, $mid, $p2, $part_n . '.' . ($part_n2 + 1));
            }
        }
        return $content;
    }


    public function markAsRead( $index ) {
        imap_setflag_full($this->imapBox, $index, "\\Seen \\Flagged", ST_UID);
    }
    public function deleteMail( $msgId ) {
        if( $msgId == null || $msgId == "" || $msgId === 0 ) return false;
        foreach( $this->virutalBox as $k=>$mail ) {
            if( $mail['header']['msg_id'] == $msgId ) {
                imap_delete($this->imapBox,$mail['header']['msg_no']);
                imap_expunge($this->imapBox);
                unset($this->virutalBox[$k]);
                return true;
            }
        } 
        return false;
    }

    public function formatHeaderInfos( $header ) {
        $datas = [];
        $datas['msg_id'] = $header->message_id ?? null;
        $datas['msg_no'] = intval($header->Msgno);
        $datas['date'] = date("Y-m-d G:i:s", strtotime($header->date));
        $datas['subject'] = $header->subject;
        $datas['from'] = $header->fromaddress;
        $datas['sender'] = $header->senderaddress;
        $datas['size'] = $header->Size;
        return $datas;
    }


}
