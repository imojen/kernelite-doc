<?php

class ImageManager {

    public function err( String $msg ) {
        err("[ImageManager] ".$msg);
    }

    public function resizeToMax( String $path, Int $maxDimension = 800, String $dest = "" ) {
        if( $dest == "" ) $dest = $path;
        if( !file_exists($path) ) $this->err("resizeToMax : Fichier introuvable $path ");
        try {
            $info = getimagesize($path);
        }
        catch( Exception $e ) {
            $this->err("resizeToMax : getimagesize failed, ".$e->getMessage());
        }
        $mime = $info['mime'];
        switch ($mime) {
            case 'image/jpeg':
                $image_create_func = 'imagecreatefromjpeg';
                $image_save_func = 'imagejpeg';
                break;
            case 'image/png':
                $image_create_func = 'imagecreatefrompng';
                $image_save_func = 'imagepng';
                break;
            case 'image/gif':
                $image_create_func = 'imagecreatefromgif';
                $image_save_func = 'imagegif';
                break;
            default: 
                return false;
        }
            
        $width = $info[0];
        $height = $info[1];
        $modwidth = $maxDimension;
        if( $width <= $maxDimension && $height <= $maxDimension )
            return true;
        $diff = $width / $modwidth;
        $modheight = $height / $diff;
        $tn = imagecreatetruecolor($modwidth, $modheight) ;
        imagealphablending($tn, false);
        imagesavealpha($tn, true);        
        $image = $image_create_func($path) ;
        imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ;
        
        /* dir control */
        $dir = pathinfo($dest)['dirname'];
        if( !is_dir($dir) ) mkdir($dir,0777,true);
        
        $image_save_func($tn, $dest) ;            
        return true;
    }

}