<?php

global $memoryRoutes;

class Routes {

    private String $path;
    private Array $routes;
    public $files = [];
    
    public function __construct() {
        
        $this->routes = [];
        $this->parseAnnotation();
        $this->path = join_paths([ROUTES]);
        $this->files = [];
        if( file_exists($this->path) ) 
            $this->files = $this->getFiles( $this->path );
        $this->processFiles();
        $this->checkIntegrity();
    }

    public function getFiles( $path ) {
        $list = [];
        $files = array_diff(scandir($path),[".",".."]);
        if( empty($files) ) return [];
        foreach( $files as $file ) {
            $filePath = join_paths([$path,$file]);
            if( is_dir($filePath) ) 
            $list = array_merge($list,$this->getFiles($filePath));
            if( strpos($filePath,".yaml") > -1 )
            $list[] = $filePath;
        }
        return $list;
    }
    
    public function processFiles() {
        foreach( $this->files as $file ) {
            $name = core::getFileName( $file, false );
            try {
                if( trim(file_get_contents($file)) != "" ) 
                $this->routes[$name] = Spyc::YAMLLoad( $file );
            } catch( Exception $e ) {
                throw new KernelError( $e->getMessage());
            }
        }
        
        // check routes
        foreach( $this->routes as $files ) {
            foreach( $files as $name => $route ) {
                if( strpos($route['url'],'/kernelite/') > -1 )
                throw new KernelError("Les routes /kernelite/ sont protégées et ne peuvent pas être utilisées ($name)");
            }
        }
        
        $memoryRoutes = $this->routes;
        return $this;
    }
    
    public function getRoutes() {
        return $this->routes;
    }

    public function getDefaultRoute() {
        foreach( $this->routes as $files ) {
            foreach($files as $routeName => $route ) {
                if( isset($route['default']) && $route['default'] ) {
                    if( isset($route['params']) && !empty($route['params']) ) 
                        throw new KernelError("La route par défaut @$routeName ne doit pas avoir de parametres obligatoires");
                    if( isset($route['api']) && $route['api'] == true ) 
                        throw new KernelError("La route par défaut @$routeName ne doit pas être en API");
                    $route['name'] = $routeName;
                    return $route;
                }
            }
        }
        throw new KernelError("Aucune route par défaut n'a été définie");
    }

    public function checkIntegrity() {
        global $memoryRoutes;
        $memoryRoutes = [];
        foreach( $this->routes as $fileName => $files ) {
            foreach($files as $routeName => $route ) {
                if( isset($memoryRoutes[$routeName]) )
                    throw new KernelError("La route $routeName a déjà été déclarée ($fileName.yaml)");
                if( in_array($route['url'],$memoryRoutes) )
                    throw new KernelError("L'URL de la route $routeName est déjà utilisée");
                $memoryRoutes[$routeName] = $route['url'];
            }
        }
        return $this;
    }

    public static function getRouteFromName( String $name ) {
        global $memoryRoutes;
        return $memoryRoutes[$name] ?? false;
    }

    public function parseAnnotation() {
        $this->routes['annoted'] = [];
        $controllers = scandir(CONTROLLERS);
        foreach( $controllers as $file ) {
            $path = path(CONTROLLERS."/".$file);
            if( !file_exists($path) || !strpos($path,".php") ) continue;
            
            $tmp = explode(".",$file);
            $fn = trim($tmp[0]);
            if( strpos($fn,"Controller") ) $fn = str_replace("Controller","",$fn);
            $className = $fn;

            $content = file($path);
            foreach( $content as $nb=>$line ) {
                $line = trim(preg_replace('/\t+/', '', $line));
                if( $line == "" ) continue;
                if(  str_split($line)[0] == "#" && str_contains(strtolower($line),"@route")) {
                    $route = $this->getRouteFromAnnotation($line,$content[$nb+1]??null);
                    if( $route ) {
                        $controller = $className."::".$route['methode'];
                        $route['controller'] = $controller;
                        $this->routes['annoted'][$route['name']] = $route;
                    }
                }
            }
        }
        return $this;
    }

    private function getRouteFromAnnotation( String $line, $funcLine ) {
        if( !$funcLine ) return false;
        $explodeChar = "=";
        $tmp = explode($explodeChar,$line);
        if( count($tmp) < 2 ) return false;
        array_shift($tmp);
        $json = trim(implode("=",$tmp));
        try {
            $o = json_decode($json,true);
        }
        catch( Exception $e ) {
            err( "Impossible de décoder l'annotation : ".$e->getMessage() );
        }
        if(!isset($o['url'])  )
            err("Annotation : les routes doivent contenir les paramètres url et name");
        if( strpos($funcLine,"function") < 1 ) return false;
        $tmp = explode("function",$funcLine);
        list($funcName) = explode("(",trim($tmp[1]));
        $o['methode'] = $funcName;
        if( !isset($o['name'] )) $o['name'] = $funcName;
        return $o;
    }

}