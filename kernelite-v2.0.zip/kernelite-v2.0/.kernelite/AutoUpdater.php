<?php

require_once('Daemon.php');
class AutoUpdater extends Daemon {

    private $url_update = 'https://kernelite.snew.fr/getLatestVersion';
    private $url_fetch = 'https://kernelite.snew.fr/downloads/';
    private $version = [];
    private $updatable = true;
    private $updateFolder;
    private $zip;
    private $tmpNew;
    private $count = 0;
    private $exclude =  [
        ".conf",
        ".structures",
        "controllers",
        "files",
        "templates",
        "tmp",
        "index.php",
        "assets/js/app.js",
        "assets/css/style.js",
    ];

    public function __construct() {
        if( !defined('PHPCLI') || !PHPCLI ) 
            throw new KernelError("AutoUpdater uniquement disponible via CLI");
        $this->verbose = true;
        $this->checkForUpdate();   
        if( !$this->updatable ) return;
        $this->processUpdate();   
        
        $this->log();
        $this->log();
    }

    private function checkForUpdate() {
        $this->log("\r\n🆙 UPDATE MODE .kernelite 🆙","important");
        $this->log("----------------------------\r\n","important");
        $this->log("Version actuelle du système : .................. .kernelite v".KVERS,"info");
        $this->log("Date de la version actuelle du système : ....... ".KVERSD,"info");
        $this->log();

        $this->log("Recherche de mise à jour disponible...","success");
        $this->log();
        //sleep(1);

        $http = new HttpClient();
        $http->setURL($this->url_update);
        $http->setMethod('GET');
        $http->execute();

        $response = $http->response();
        if( !isset($response['kernelite']) ) {
            $this->log("Impossible de contacter le serveur.","info");
            $this->log($http->getError());
            return;
        }
        $this->log("Dernière version système disponible : .......... .kernelite v".$response['kernelite']['version'],"info");
        $this->log("Date de la dernière version : .................. ".core::dateOutput($response['kernelite']['date']),"info");   
        $this->log();
        
        if( floatval($response['kernelite']['version']) <= floatval(KVERS) ) {
            $this->updatable = false;
            return $this->log("Aucune mise à jour n'est disponible.","success");
        }

        $this->log("Une mise à jour disponible !", "success");
        $this->log();

        $this->version = $response['kernelite'];
        return $this;
    }

    private function processUpdate() {
        $this->log("Début du processus de mise à jour","important");
        $this->initUpdateFolders();
        $this->log();
        $this->download();
        $this->log();
        $this->unzip();
        $this->log();
        $this->copyVers();
        $this->log();
        




        $this->cleanTemporary();
        $this->log();
        $this->log("Mise à jour terminée","important");
        $this->log("Vous utilisez désormais .kernelite v".$this->version['version']." !","important");
    }

    private function download() {
        $this->log("Téléchargement de : .kernelite v".$this->version['version']." ...","info");
        $from = $this->url_fetch.$this->version['file'];
        $this->zip = $this->updateFolder.$this->version['file'];

        $dl_start = microtime(true);
        if ( !file_put_contents($this->zip, file_get_contents($from)) ) 
            err("Impossible de télécharger : $from");
        $dl_end = microtime(true);
        $delta = number_format($dl_end-$dl_start,2,","," "); 
        $this->log("Téléchargement terminé (".core::readableSize(filesize($this->zip))." en $delta secondes)","info");
    }

    private function initUpdateFolders() {
        $this->log("Création du dossier temporaire de mise à jour...","info");
        $this->updateFolder = path( kRoot()."tmp/.kernelite/".uniqid("update_")."/" );
        if( !is_dir($this->updateFolder) ) {
            try {
                $old = umask(0);
                mkdir($this->updateFolder, 0777, true);
                umask($old);
            }
            catch( Exception $e ) {
                throw new KernelError( $e->getMessage() );
            }
        }
        if( !is_dir($this->updateFolder) || !is_writable($this->updateFolder) )
            throw new KernelError("Impossible de créer ou d'accéder au repertoire temporaire de mise à jour : ".$this->updateFolder);
        $this->log("Dossier créé : ".$this->updateFolder,"info");
    }

    private function cleanTemporary() {
        $this->log("Nettoyage des fichiers temporaires...","info");
        $this->removeDirectory($this->updateFolder);
        if( is_dir($this->updateFolder) )
            err("Impossible de supprimer le dossier ".$this->updateFolder);
        $this->log("Nettoyage terminé","info");
    }

    private function removeDirectory($path) {
        $files = array_diff(scandir($path),[".",".."]);
        foreach ($files as $file) {
            is_dir($path.$file) ? $this->removeDirectory($path.$file."/") : unlink($path.$file);
        }
        rmdir($path);    
        return;
    }

    private function unzip() {
        $this->log("Décompression de l'achive...","info");
        $o = new ZipArchive;
        if( !$o->open($this->zip) )
            err("Impossible d'ouvrir l'archive ".$this->zip);
        $this->tmpNew = $this->updateFolder.$this->version['version'];
        $o->extractTo($this->tmpNew);
        if( !is_dir($this->tmpNew) )
            err("L'extraction de l'archive a échoué");
        $this->log("Archive décompressée.","info");        
    }

    private function copyVers() {

        $content = array_diff(scandir($this->tmpNew),[".",".."]);
        foreach( $content as $k=>$e )
            if( in_array($e,$this->exclude) )
                unset($content[$k]);
        $this->log("Début de copie des nouveaux fichiers...","info");
        foreach( $content as $k=>$e ) {
            try {
                $this->copyFile( path($this->tmpNew."/".$e), path(kroot().$e) );
            }
            catch( Exception $e ) {
                throw new Exception( $e->getMessage() );
            }
        }
        $this->log("Copie terminée : ".$this->count." fichier(s) ","info");        
    }
    private function copyFile( $from, $to ) {
        $nameTo = str_replace(kroot(),"",$to);        
        if( in_array($nameTo,$this->exclude) ) return;
        if( is_dir($from) ) {
            $subcontent = array_diff(scandir($from),[".",".."]);
            foreach( $subcontent as $element ) 
                $this->copyFile( path($from."/".$element), path($to."/".$element) );
        }
        else {
            $pi = pathinfo($to);
            if( !is_dir($pi['dirname']) ) {
                $old = umask(0);
                mkdir($pi['dirname'], 0777, true);
                umask($old);
            }
            copy( $from, $to );
            $this->count++;
        }
        //$nameFrom = str_replace(kroot(),"",$from);
        //$nameTo = str_replace(kroot(),"",$to);        
        //$this->log("\tSource : $nameFrom → Destination : $nameTo");
    }


}