<div class="container text-center mt-5">
    <img src="{{project_url}}assets/css/vendor/images/kernelite-logo-m.png"/>
    <div class="alert alert-primary mt-3">
        Nous sommes le {{date}}, et il est {{heure}}
    </div>
    <a href="{% route(index) %}" class="btn btn-info">Retour à l'accueil</a>
</div>