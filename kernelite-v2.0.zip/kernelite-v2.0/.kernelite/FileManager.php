<?php

class FileManager {

    private $stream;

    public function __construct() {
        $this->checkDirs();
    }

    public function checkDirs() {
        if( TMP == "" ||  FILES == "" )
            crashError( "Veuilez définir correctement la directive <strong>user_uploads</strong> " );
        $dirs = [TMP,FILES];
        foreach( $dirs as $dir ) {
            if( !is_dir($dir) ) {
                try{
                    mkdir( $dir, 0700);
                    if( !is_dir($dir) )
                    throw new KernelError( "Impossible de créer le dossier : $dir " );
                }
                catch( Exception $e ) {
                    throw new KernelError( $e->getMessage() );
                }
            }
            if( !is_readable($dir) )
                throw new KernelError( "Le dossier $dir n'est pas accessible en lecture" );
            if( !is_writable($dir) )
                throw new KernelError( "Le dossier $dir n'est pas accessible en écriture" );
        }
    }

    public function getRandDir() {
        $name = md5(time().rand(100000,999999));
        $path = join_paths([TMP,$name]);
        try {
            mkdir( $path, 0700, true);
        }
        catch( Exception $e ) {
            throw new KernelError($e->getMessage());
        }
        return $name;
    }

    public function asyncFileUpload( $files ) {
        if( !isset($files['kerneliteUpload']) )
            throw new KernelError('Objet kerneliteUpload non reçu');
        $files = $files['kerneliteUpload'];
        $safety = "(bat|exe|cmd|sh|php([0-9])?|pl|cgi|386|dll|com|torrent|js|app|jar|pif|vb|vbscript|wsf|asp|cer|csr|jsp|drv|sys|ade|adp|bas|chm|cpl|crt|csh|fxp|hlp|hta|inf|ins|isp|jse|htaccess|htpasswd|ksh|lnk|mdb|mde|mdt|mdw|msc|msi|msp|mst|ops|pcd|prg|reg|scr|sct|shb|shs|url|vbe|vbs|wsc|wsf|wsh)";
        if( UPLOAD_SAFE_MODE ) {
            foreach( $files['name'] as $name ) {
                $tmp = explode(".",$name);
                $ext = array_pop($tmp);
                if( preg_match($safety,$ext) ) {
                    throw new KernelError("Le type d'un des fichiers envoyés a été refusé pour des raisons de sécurité");
                }
            }
        }
        $tmpName = $this->getRandDir();
        $tmpDir = join_paths([TMP,$tmpName]);
        $response = [
            "tmp" => $tmpName,
            "files" => []
        ];
        foreach( $files['tmp_name'] as $k=>$tmp_file ) {
            try {
                $name = $files['name'][$k];
                move_uploaded_file($tmp_file, join_paths([$tmpDir,$name]) );
                $response['files'][] = $name;
            }
            catch( Exception $e ) {
                throw new KernelError($e->getMessage());
            }
        }
        core::apiSuccess($response);
    }

    public function removeTmpDir( Array $post ) {
        $tmpDir = $post['tmpDir'];
        $path = join_paths([TMP,$tmpDir]);
        $files = core::getFilesFromDir($path);
        foreach( $files as $file ) {
            $p = join_paths([$path,$file]);
            if( is_dir($p) ) $this->removeTmpDir( ["tmpDir" => join_paths([$tmpDir,$file])] );
            try {
                unlink($p);
            }
            catch( Exception $e ) {
                throw new KernelError($e->getMessage());
            }
        }
        try {
            rmdir($path);
        }
        catch( Exception $e ) {
            throw new KernelError($e->getMessage());
        }
        core::apiSuccess([]);     
    }

    public function open( String $path ) {
        if( !file_exists($path) )
            throw new KernelError("Fichier inexistant");
        if( !is_readable($path))
            throw new KernelError("Impossible de lire le fichier (droits)");
        try {
            $this->stream = file($path);
            if( $this->stream ) {
                foreach( $this->stream as $k=>$e ) {
                    $this->stream[$k] = utf8_encode($e);
                }
            }
        } catch( Exception $e ) {
            throw new KernelError($e->getMessage);
        }
        return $this;
    }

    public function getStream() {
        return (array)$this->stream;
    }

    public function formatCsv( String $separator = ";", Bool $headerKeys = false ) {
        if( !$this->stream ) return $this;
        $content = $this->stream;

        if( $headerKeys ) 
            $headers = explode($separator,array_unshift($content));

        $this->stream = [];
        foreach( $content as $line ) {
            $line = trim($line);
            $explodedLine = explode($separator,$line);
            if( !$headerKeys )  
                $this->stream[] = $explodedLine;
            else {
                $tmp = [];
                foreach( $headers as $numHeader => $key ) 
                    $tmp[$key] = $explodedLine[$numHeader];
                $this->stream[] = $tmp;
            }
        }
        return $this;
    }

    public function moveFile( String $from, String $to, Bool $overwrite = true ) {
        $from = core::normalizePath($from);
        if( !file_exists($from) || !is_file($from) ) {
            err("moveFile : le fichier n'existe pas $from");
        }
        $to = core::normalizePath($to);
        if( is_file($to) && $overwrite === false ) return false;
        $finalFileName = basename($from);
        $tmp = explode(DS,$to);
        $last = array_pop($tmp);
        if( strpos($last,".") > -1 ) $finalFileName = $last;
        else $tmp[] = $last;
        $newDir = implode(DS,$tmp);
        if( !is_dir($newDir) ) {
            try {
                $oldmask = umask(0);
                mkdir( $newDir, 0777, true );
                umask($oldmask);
            }
            catch( Exception $e ) {
                err("FileManager : erreur lors de la création des répertoires<br/>".$e->getMessage());
            }
        }
        $finalName = $newDir.DS.$finalFileName;
        try {
            rename( $from, $finalName );
        } catch( Exception $e ) {
            err("FileManager : erreur lors du deplacement<br/>".$e->getMessage());
            return false;
        }
        return $finalName;
    }

    
    public static function cleanTmpDir( String $deadline = "-2 hours" ) {
        $tmp = kroot().TMP;
        $list = array_diff(scandir($tmp),[".",".."]);
        $deadline = strtotime($deadline);
        foreach( $list as $k=>$e ) {
            $p = path($tmp."/".$e);
            if( filemtime($p) < $deadline ) {
                try {
                    if( is_dir($p) ) {
                        if( strpos($p,$tmp) > -1 )
                            shell_exec("rm -rf '$p' ");
                    }
                    else unlink($p);
                }
                catch( Exception $e ) {
                    err( $e->getMessage() );
                }
            }
        }
    }




}