<?php
// Welcome to .kernelite =)
// Edit at your own risks.
$ds = DIRECTORY_SEPARATOR;
global $kAppRoot;
$kAppRoot = dirname(__FILE__).$ds;
include_once(".kernelite".$ds."__index.php");
exit;
?>