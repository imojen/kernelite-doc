<?php
class Events {
    public static function on( String $eventName, Callable $callable) {
        global $kEventListeners;
        if( is_null($kEventListeners) ) $kEventListeners = [];
        if( !self::exists($eventName) ) $kEventListeners[$eventName] = [];
        $kEventListeners[$eventName][] = $callable;
    }
    private static function exists( String $eventName ) {
        global $kEventListeners;
        return isset($kEventListeners[$eventName]);
    }
    public static function emit( String $eventName, ...$args ) {
        global $kEventListeners;
        $datas = [];
        if( self::exists($eventName) ) {
            foreach( $kEventListeners[$eventName] as $func ) {
                try {
                    $datas[] = call_user_func_array($func, $args );
                }
                catch( Exception $e ) {
                    err( $e->getMessage() );
                }
            }
            if( empty($datas) ) return;
            if( count($datas) == 1 ) return array_pop($datas);
            return $datas; 
        }
        return;
    }
}