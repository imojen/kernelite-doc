<?php

class Mailer {

 
	public $to;
	public $title;
	public $body;
	public $sender;
	public $senderMail;
	public $replyTo;
	public $replyToMail;
	public $headers;

	public function __construct( $to, $title, $body, $pseudoTitle = PROJECT_NAME ) {
		$this->to = $to;
		$this->title = '=?UTF-8?B?'.base64_encode($title).'?=';
		$this->body = '
			<div style="font-weight:bold;font-size:25px;margin: 20px 0;color:#000;">
				'.$pseudoTitle.'
			</div>
			<div style="font-size:13px;color:#333;">'.$body."</div>";

		$this->send();

		return $this;
	}

	public function send() {
		$this->sender = MAILER_SENDER;
		$this->senderMail = MAILER_SENDERMAIL;
		$this->replyTo = MAILER_REPLYTO;
		$this->replyToMail = MAILER_REPLYTOMAIL;
		$this->headers = array(
		'From: '.$this->sender.' <'.$this->senderMail.'>',
		'Reply-To: '.$this->replyTo.'<'.$this->replyToMail.'>',
		'Return-Path: '.$this->sender,
		'MIME-Version: 1.0',
		'Content-Type: text/html; charset=UTF-8',
		'X-Priority: 1',			
		);
		if( !mail($this->to, $this->title, $this->body, implode("\r\n",$this->headers) ) ) {
			throw new KernelError("Erreur du serveur : Impossible d'envoyer l'email.");
		}
		else {
			return $this;
		}
	}


}