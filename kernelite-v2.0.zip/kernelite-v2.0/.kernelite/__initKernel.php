<?php
session_start();

define('KVERS', "2.0" );
define('KVERSD', "10/06/2024" );

define('CONF', join_paths([APP_ROOT,'.conf']) );
define('STRUC', join_paths([APP_ROOT,'.structures']) );
define('CONTROLLERS',join_paths([APP_ROOT,'controllers']));
define('SERVICES',join_paths([APP_ROOT,'services']));
define('ENTITIES',join_paths([APP_ROOT,'entities']));


define('KERNELITE',join_paths([APP_ROOT,'.kernelite']));
define('ROUTES',join_paths([APP_ROOT,'routes']));
define('EVENTS',join_paths([APP_ROOT,'events']));
define('TEMPLATES', join_paths([APP_ROOT,'templates']));
define('FRAGMENTS', join_paths([TEMPLATES,'.fragments']));
define('ASSETS', join_paths([APP_ROOT,'assets']));
define('PLUGINS', join_paths([ASSETS,'plugins']));

# PHP Input
global $phpInput;
$phpInput = file_get_contents('php://input');

# Autoloader
__incPHP(KERNELITE);
require_once( join_paths([KERNELITE,'_autoloader.php']) );
spl_autoload_register('magicAutoloader');

# Events
__incPHP(EVENTS);

# Vendors
$vendors = join_paths([APP_ROOT,'vendor']);
if( is_dir($vendors) ) {
    $vendorsAutoload = join_paths([$vendors,'autoload.php']);
    if( file_exists($vendorsAutoload) )
    require_once( $vendorsAutoload );
}
Events::emit('vendors.loaded');


/* Global CONF */
define('PROJECT_NAME', $GLOBAL_PARMS['project']['title']);
define('ENV', $GLOBAL_PARMS['project']['environnement']);
define('DEV', strtolower(ENV) == 'dev');
define('URL', $GLOBAL_PARMS['project']['public_url']);
define('CACHE', $GLOBAL_PARMS['cache']['use']);
define('CSTR', CACHE ? '' : '?'.time()   );
# FILES
define('TMP', $GLOBAL_PARMS['directories']['user_uploads']['tmp'] );
define('FILES', $GLOBAL_PARMS['directories']['user_uploads']['store'] );
define('UPLOAD_SAFE_MODE', $GLOBAL_PARMS['directories']['safe_mode']);


/* API */
define('API_ONLY', isset($GLOBAL_PARMS['api']['only']) && $GLOBAL_PARMS['api']['only'] === true);
if( API_ONLY ) {
    define('API_TOKEN_DELAY', intval( $GLOBAL_PARMS['api']['token']['expire'] ) ?? 3600 );
    define('API_TOKEN_NAME', $GLOBAL_PARMS['api']['token']['name'] ?? false );
    define('API_TOKEN_EXPIRE', API_TOKEN_NAME ? API_TOKEN_NAME."_expire" : null );
    define('API_TOKEN_STRUC', $GLOBAL_PARMS['api']['token']['structure'] ?? false );
    if( !API_TOKEN_NAME )
        crashError("Veuillez renseigner le champ [api][token][name]");
    if( !API_TOKEN_STRUC ) 
        crashError("Veuillez renseigner le champ [api][token][structure]");
        
}



# BDD
global $kDatabases;
$kDatabases = [];
define("DATAMANAGER", defined('NODBMODE') && NODBMODE == false );
if( DATAMANAGER ) {
    foreach( $GLOBAL_PARMS['databases'] as $k=>$db ) {
        if( isset($kDatabases[$db['name']]) )
            err("Double définition de la base : ".$db['name']);
        $kDatabases[$db['name']] = $db;
        if( $db['name'] == "main" ) {
            define("DB_MODE", $db['mode']);
            define("DB_HOST", $db['host']);
            define("DB_USER", $db['user']);
            define("DB_PASS", $db['password']);
            define("DB_NAME", $db['base']);        
        }
    }
    if( !defined('DB_HOST') )
        crashError("Vous devez avoir une base de données nomée : main");
}

define("DEBUG_DB", false);
define('DB_SALT', "");


# Timezone
date_default_timezone_set($GLOBAL_PARMS['date']['timezone']);

# Mailer
define("MAILER_SENDER", $GLOBAL_PARMS['mailer']['sender']);
define("MAILER_SENDERMAIL", $GLOBAL_PARMS['mailer']['senderMail']);
define("MAILER_REPLYTO", $GLOBAL_PARMS['mailer']['replyTo']);
define("MAILER_REPLYTOMAIL", $GLOBAL_PARMS['mailer']['replyToMail']);

# PHP Mailer
define("PHPMAILER", $GLOBAL_PARMS['PHPMailer']['use'] ?? false);


// Super globales custom
Events::emit('define.superglobales');


function join_paths($paths) {
    if( is_array($paths) && count($paths) > 1 ) {
        $tmp = [];
        foreach( $paths as $p ) {
            if( strpos($p,DIRECTORY_SEPARATOR) > -1 ) {
                $tmp = array_merge($tmp,explode(DIRECTORY_SEPARATOR,$p));
            }
            else $tmp[] = $p;
        }
        $paths = $tmp;
    }
    try {
        $return = preg_replace('~[/\\\\]+~', DIRECTORY_SEPARATOR, implode(DIRECTORY_SEPARATOR, $paths));
    } catch( Exception $e ) {
        throw new KernelError($e->getMessage());
    }
    return $return;
}
function __incPHP( String $dir ) {
    if( !file_exists($dir) || !is_dir($dir) )
        return;
    foreach( scandir($dir) as $file ) {
        if( strpos($file,".php") > -1 ) 
            include_once( join_paths([$dir,$file]));    
    }
}



# Dev errors
if( ENV == "PROD" ) {
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
    error_reporting(0);
}
if( ENV == "DEV" ) {
  ini_set('display_errors', 0);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);
  set_error_handler("devErrorHandler", E_ALL);    
  register_shutdown_function( "devFatalErrorHandler" );
}
global $kErrorHandled, $k_doNotThrow; 
$k_doNotThrow = false;
function devErrorHandler($errno, $errstr) { 
    global $kErrorHandled, $k_doNotThrow;
    $kErrorHandled = true;
    if( $k_doNotThrow ) return (string) $errstr; 
    throw new KernelError( (string) $errstr, true);
}
function devFatalErrorHandler() {
    global $kErrorHandled;
    if( $kErrorHandled === true ) return;
    $err = error_get_last();
    if( $err !== NULL ) 
        throw new KernelError($err['message'], true);
}
function k_doNotThrowError( Bool $state ) {
    global $k_doNotThrow;
    $k_doNotThrow = $state;
}
