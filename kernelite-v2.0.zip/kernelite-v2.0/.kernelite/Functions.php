<?php

global $oneDHighlight;

class Functions {

    public function initSuperGlobals() {
        global $oneDHighlight;
        $oneDHighlight = false;
        $this
            ->_dumps()
            ->_routes()
            ->_errors()
            ->_sendmail()
            ->_dataManager()
            ->_structures()
            ->_load_styles()
            ->_load_scripts()
            ->tools();

    }

    private function _dumps() {
        if( !function_exists('d') ) {
            function d( $obj, Bool $buffer = false, Array $caller = [] ) {
                if(PHPCLI) {
                    print_r($obj);
                    return;
                }
                global $oneDHighlight;
                $output = [];
                $style = $h1Style = $h2Style = $dumpStyle = [];
                $stylePath = join_paths([CONF,'dump-style.php']);
                if( file_exists($stylePath) )
                    include($stylePath);
                if( $caller == [] ) {
                    $i = debug_backtrace();
                    $caller = $i[1];
                    if( $caller['function'] == "include" ) $caller = $i[2];
                }

                $callerName = [];
                foreach( debug_backtrace() as $e )
                    $callerName[] = (isset($e['class']) && $e['class'] != "" ? $e['class']."→" : '').$e['function'];
                $callerName = array_reverse($callerName);
                array_pop($callerName); // supprimer d()
                $callerName = implode(' ► ',$callerName);

                $tmp = explode(DIRECTORY_SEPARATOR, $caller['file']);
                $dName = array_pop($tmp).( ( $caller['line'] ?? 0) > 0 ? " - ligne ".$caller['line'] : "" );

                $output[] = '<div style="'.implode(';',$style).'">';
                $output[] = "<h1 style='".implode(";",$h1Style)."'>$dName</h1>";
                $output[] = "<h2 style='".implode(";",$h2Style)."'>".$callerName."</h2>";
                $output[] = '<div style="'.implode(';',$dumpStyle).'">';
                ob_start();
                var_dump($obj);
                $string = ob_get_contents();
                ob_end_clean();        
                $output[] = highlight_string("<?php\n " . $string . "?>", true);
                $output[] = '</div>';
                if( !$oneDHighlight ) {
                    $oneDHighlight = true;
                    $output[] = '
                    <script>
                        if( document.getElementsByTagName("code")[0].getElementsByTagName("span")[1] ) {
                            document.getElementsByTagName("code")[0].getElementsByTagName("span")[1].remove();
                            document.getElementsByTagName("code")[0].getElementsByTagName("span")[document.getElementsByTagName("code")[0].getElementsByTagName("span").length - 1].remove();
                        }
                    </script>';
                }
                $output[] = '</div>';
        
                if( $buffer ) {
                    ob_start();
                    echo implode($output);
                    $str = ob_get_contents();
                    ob_end_clean();
                    return $str;
                }
                echo implode($output);
                return;
            }
        }
        
        if( !function_exists('dd') ) {
            function dd($obj) {
                if( !function_exists('d') ) return;
                $i = debug_backtrace(); 
                d($obj, false, $i[1] ?? []);
                die();
            }
        }
        
        return $this;
    }


    private function _routes() {
        if( !function_exists('route') ) {
            function route( String $routeName ) {
                if( $routeName == "disconnect" ) {
                    echo URL.'disconnect'; 
                    return;
                }               
                $newURL = Routes::getRouteFromName($routeName);
                if( $newURL === false )
                    throw new KernelError("Aucune route nomée $routeName n'a été trouvée");
                echo URL.substr($newURL,1);
            }
            if( !function_exists('r') ) {
                function r(String $routeName) {
                    route($routeName);
                }
            }
        }   
        return $this;     
    }

    private function _errors() {
        if( !function_exists('err') ) {
            function err( $message ) {
                throw new KernelError($message);
            }
        }
        return $this;
    }

    private function _sendmail() {
        if( !function_exists('sendmail') ) {
            function sendmail( $params = [] ) {
                if( !isset($params['to'],$params['title'],$params['body']) )
                    throw new KernelError("Il manque des paramètres pour l'envoi de mail");
                return new Mailer($params['to'],$params['title'],$params['body']);
            }
        }
        return $this;        
    }

    private function _dataManager() {
        if( !function_exists('dm') ) {
            function dm( $connection = "" ) {
                if( $connection == "" ) {
                    global $Kernelite;
                    return $Kernelite->dm;
                }
                return new DataManager($connection);
            }
        }  
        if( !function_exists('req') ) {
            function req() {
                global $Kernelite;
                return $Kernelite->req;
            }
        }         
        return $this;
    }

    private function _structures() {
        if( !function_exists('structure') ) {
            function structure( String $name ) {
                return Structure::get($name);
            }
            if( !function_exists('s') ) {
                function s( String $name ) {
                    return Structure::get($name);
                }
            }
            if( !function_exists('form') ) {
                function form( String $name, String $f = "form" ) {
                    return Structure::printForm( $name, null, $f );
                }
            }
            if( !function_exists('form_widget') ) {
                function form_widget( String $name, $widget = null, String $f = "form" ) {
                    return Structure::printForm( $name, $widget, $f );
                }
            }            
        }
        return $this;        
    }



    private function _load_styles() {
        if( !function_exists('__kernel_load_styles') ) {
            function __kernel_load_styles( Controller $obj = null, Array $options = [] ) {
                $load = [];

                if( !isset($options['framework']) || $options['framework'] == false ) {
                    $paths = [
                        join_paths([ASSETS,'css','vendor']),
                        join_paths([ASSETS,'css']),
                    ];
                    # Autoload framework
                    foreach( $paths as $path ) {
                        $files = core::getFilesFromDir($path);
                        foreach( $files as $file ) {
                            if( strpos($file,'.css') > -1 )
                                $load[] = join_paths([$path,$file]);
                        }
                    }
                }

                if( $obj ) {
                    # Default css controller template
                    if( !isset($options['default']) || $options['default'] == false ) {
                        $className = get_class($obj);
                        $potentialDefaultControllerCss = join_paths([ASSETS,'css','templates',strtolower($className).".css"]);
                        if( file_exists($potentialDefaultControllerCss) ) 
                            $load[] = $potentialDefaultControllerCss;
                    }
                
                    # Declared properties controller css        
                    if( isset($obj->templateParameters['parameters']['styles']) ) {
                        $styles = $obj->templateParameters['parameters']['styles'];
                        if( !is_array($styles) ) $styles = [$styles];
                        foreach( $styles as $style ) {
                            $path = join_paths([ASSETS,'css','templates',$style]);
                            if( !strpos($path,".css") ) $path .= ".css";
                            if( !file_exists($path) )
                                throw new KernelError("Feuille de style du controller introuvable<br/>$path");
                            if( !in_array($path,$load) )
                                $load[] = $path;
                        }
                    }

                    # Intuitive method's css
                    global $Kernelite;
                    if( isset($Kernelite->req->route['controller']) ) {
                        $_tmp = explode("::", strtolower($Kernelite->req->route['controller']) );
                        if( $_tmp[0] != "" && $_tmp[1] != "" ) {
                            $_xpath = join_paths([ASSETS,'css','templates', $_tmp[0], $_tmp[1].".css"]);
                            if( file_exists($_xpath) ) $load[] = $_xpath;
                        }
                    }

                }

                # Output
                foreach( $load as $stylesheets) {
                    $link = str_replace(APP_ROOT,URL,$stylesheets).CSTR;
                    echo '<link rel="stylesheet" href="'.$link.'">';
                }
            }
        }
        return $this;        
    }

    private function _load_scripts() {
        if( !function_exists('__kernel_load_scripts') ) {
            function __kernel_load_scripts( Controller $obj = null, Array $options = [] ) {
                $load = [];

                if( !isset($options['framework']) || $options['framework'] == false ) {
                    $paths = [
                        join_paths([ASSETS,'js','vendor']),
                        join_paths([ASSETS,'js','.kernelite']),
                        join_paths([ASSETS,'js']),
                    ];
                    # Autoload framework
                    foreach( $paths as $path ) {
                        $files = core::getFilesFromDir($path);
                        foreach( $files as $file ) {
                            if( strpos($file,'.js') > -1 )
                                $load[] = join_paths([$path,$file]);
                        }
                    }
                }

                if( $obj ) {

                    # Default JS controller template
                    if( !isset($options['default']) || $options['default'] == false ) {
                        $className = get_class($obj);
                        $potentialDefaultControllerJS = join_paths([ASSETS,'js','templates',strtolower($className).".js"]);
                        if( file_exists($potentialDefaultControllerJS) ) 
                            $load[] = $potentialDefaultControllerJS;
                    }
                
                    # Declared properties controller JS        
                    if( isset($obj->templateParameters['parameters']['scripts']) ) {
                        $scripts = $obj->templateParameters['parameters']['scripts'];
                        if( !is_array($scripts) ) $scripts = [$scripts];
                        foreach( $scripts as $script ) {
                            $path = join_paths([ASSETS,'js','templates',$script]);
                            if( !strpos($path,".js") ) $path .= ".js";
                            if( !file_exists($path) )
                                throw new KernelError("Feuille de script du controller introuvable<br/>$path");
                            if( !in_array($path,$load) )
                                $load[] = $path;
                        }
                    }

                    # Intuitive method's JS
                    global $Kernelite;
                    if( isset($Kernelite->req->route['controller']) ) {
                        $_tmp = explode("::", strtolower($Kernelite->req->route['controller']) );
                        if( $_tmp[0] != "" && $_tmp[1] != "" ) {
                            $_xpath = join_paths([ASSETS,'js','templates', $_tmp[0], $_tmp[1].".js"]);
                            if( file_exists($_xpath) ) $load[] = $_xpath;
                        }
                    }                    

                }

                # Output
                echo '<script>const URL = "'.URL.'";</script>';
                foreach( $load as $scripts) {
                    $link = str_replace(APP_ROOT,URL,$scripts).CSTR;
                    echo '<script src="'.$link.'" defer></script>';
                }
            }
        }   
        return $this;        
    }

    public function tools() {
        if( !function_exists('urlize') ) {
            function urlize( String $str) {
                if( strpos($str,APP_ROOT) > -1 )
                    $str = str_ireplace(APP_ROOT,URL,$str);
                return str_replace(DS,"/",$str);
            }
        }
        if( !function_exists('connector') ) {
            function connector( String $str) {
                $c = $str.".Connector.php";
                $connector = path(KERNELITE."/Connectors/$c");
                if( file_exists($connector) ) {
                    require_once($connector);
                    return true;
                }
                else err("Connecteur non trouvé : ".$c);
            }
        }  
        if( !function_exists('getConf') ) {
            function getConf( String $str) {
                $c = $str.".yaml";
                $confFile = path(CONF."/$c");
                if( file_exists($confFile) ) 
                    return Spyc::YAMLLoad( $confFile );
                err("Fichier de conf non trouvé : ".$c);
            }
        }  
        if( !function_exists('json_validate') ) {
            function json_validate(string $string): bool {
                json_decode($string);
                return json_last_error() === JSON_ERROR_NONE;
            }
        }
            

        return $this;
    }

}