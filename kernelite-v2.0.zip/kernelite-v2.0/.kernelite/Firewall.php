<?php

class Firewall {

    private String $firewallFile;
    private Bool $enabled;
    public Bool $redirect;
    public Bool $policiesRedirection;
    private Array $file;
    private Array $policies;

    public function __construct() {
        $this->enabled = false;
        $this->redirect = false;
        $this->policiesRedirection = false;
        $this->firewallFile = join_paths([CONF,"firewall.yaml"]);
        if( !file_exists($this->firewallFile) ) return $this;
        $this->loadFile();
        $this->setEnabled();
        if( $this->isEnabled() ) {
            $this->setRedirection();
            $this->loadPolicies();
        }
        return $this;
    }

    private function loadFile() {
        $this->file = Spyc::YAMLLoad($this->firewallFile);
        if( !isset($this->file['firewall']) ) 
            crashError("Le fichier de configuration firewall.yaml doit contenir la clé 'firewall' en début de fichier.");
        $this->file = $this->file['firewall'];
        return $this;
    }
    private function setEnabled() {
        if( isset($this->file['enable']) && $this->file['enable'] === true )
            $this->enabled = true;
        return $this;
    }
    public function isEnabled() {
        return $this->enabled === true;
    }

    private function setRedirection() {
        if( !isset($this->file['redirection']) ) return $this;
        if( !is_array($this->file['redirection']) )
            crashError("Firewall : la propriété 'redirection' n'est pas définie correctement");
        
        $r = $this->file['redirection'];
        if( isset($r['enableRedirection']) && $r['enableRedirection'] === true )
            $this->redirect = true;
        if( isset($r['policiesRedirection']) && $r['policiesRedirection'] === true )
            $this->policiesRedirection = true;            
        return $this;
    }

    private function loadPolicies() {
        $this->policies = [];
        if( !isset($this->file['policies']) ) return $this;

        $policies = $this->file['policies'];
        if( !is_array($policies) )
            crashError("Firewall : mauvaise configuration des policies");
        
        $matches = [];
        foreach( $policies as $p ) {
            $police = [];

            # Checks
            if( !isset($p['match']) || !isset($p['rules']) )crashError("Firewall : il manque un attribut 'match' ou 'rules' à l'une de vos policies");
            if( trim($p['match']) == "" || !is_string($p['match'])) crashError("Firewall : le match d'une de vos policies est vide ou incorrect");
            if( trim($p['rules']) == "" || !is_string($p['rules']) ) crashError("Firewall : le rules d'une de vos policies est vide ou incorrect");
            if( in_array($p['match'],$matches) ) crashError("Firewall : plusieurs policies utilisent le match '".$p['match']."' ");

            # Match
            $matches[] = trim($p['match']);

            # Rules
            $rules = [];
            $tmp = explode(",",$p['rules']);
            foreach( $tmp as $r ) if( trim($r) != "" ) $rules[] = $r;
            if( empty($rules) ) crashError("Firewall : mauvaise définition des rules pour le match '".$p['match']."' ");
            $police["rules"] = $rules;

            # Redirect
            if( $this->redirect && $this->policiesRedirection && isset($p['redirect']) && is_string($p['redirect']) && trim($p['redirect']) != "" ) 
                    $police['redirect'] = trim($p['redirect']);

            # Police valide
            $this->policies[$p['match']] = $police;
        }
        return $this;
    }

    public function getMatch( $url ) {
        $matches = array_keys($this->policies);
        foreach( $matches as $pattern ) {
            if( $pattern == "*" ) continue;
            if( mb_strpos($url,$pattern) > -1 )
                return $this->policies[$pattern];
        }
        if( array_key_exists("*",$this->policies) )
            return $this->policies["*"];
        return false;
    }




}