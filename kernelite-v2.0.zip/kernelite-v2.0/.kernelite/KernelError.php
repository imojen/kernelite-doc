<?php

class KernelError {
    public function __construct( String $errorMessage, Bool $critical = false ) {
        if( PHPCLI) kCLICrashError($errorMessage);
        global $Kernelite;
        if( strpos($_SERVER['REQUEST_URI'],URL."api/") || 
            (isset($Kernelite->apiMode) && $Kernelite->apiMode || 
            ( defined('API_ONLY') && API_ONLY == true ) ) 
        ) {
            http_response_code(400);
            $Kernelite->apiResponse(core::apiError( $critical ? self::formatApiError($errorMessage) : $errorMessage));
        }

        global $Kernelite;
        ob_start();
        include( join_paths([KERNELITE,'templates','KernelError.php']));
        $output = ob_get_contents();
        ob_end_clean();
        echo $output;
        die();
    } 

    public static function formatApiError( $msg ) {
        if( ENV !== "DEV" ) return '<h3>Le traitement à échoué</h3>';
        $err = error_get_last();
        $h4 = "";
        if( isset($err['file'],$err['line'],$err['message']) ) {
            $file = $err['file'];
            $line = $err['line'];
            $message = $err['message'];
            $a = explode(", called in",$message);
            $message = $a[0];
        }
        else {
            $h4 = $msg;
            ob_start();
            self::printDebugTrace();
            $content = ob_get_contents();
            ob_end_clean();
        }

        
        $tmp = [];
        $tmp[] = '<h3>Le traitement à échoué</h3>';
        
        $tmp[] = '<code class="kCodeStyle mb-1" style="display: block;">';
        if( $h4 != "" ) $tmp[] = "<p>$msg</p>";
        if( isset($file) ) {
            $tmp[] = '<i class="far fa-file-alt"></i> '.str_replace(kRoot(),'',$file).' - ligne '.$line.'';
            $tmp[] = '</code>';
            $tmp[] = '<code class="kCodeStyle" style="display: block;">';
            $tmp[] = '<i class="fas fa-bug"></i> '.$message.' <br/>';
        }
        else {
            $tmp[] = $content;
        }
        $tmp[] = '</code>';
        return implode($tmp);
    }

    public static function printDebugTrace() {
        $debug = debug_backtrace();

        $padding = "0";
        echo '<div><pre style="max-height:400px; margin-top:15px;">';
        $first = [];
        foreach( $debug as $k=>$e ) {
            //var_dump($e);

            if( isset($e['file']) && mb_strpos($e['file'],'KernelError.php') )  continue;
            if( isset($e['class']) && $e['class'] == 'KernelError' ) continue;
            if( !isset($e['file']) ) continue;
            $filePath = str_replace(APP_ROOT. DIRECTORY_SEPARATOR,'',$e['file']);
            if( isset($e['function']) && $e['function'] == 'devErrorHandler' ) {
                if( isset($e['args'],$e['args'][1],$e['args'][2],$e['args'][3]) ) {
                    $f = str_replace(APP_ROOT. DIRECTORY_SEPARATOR,'',$e['args'][2]);
                    echo '<div class="alert alert-danger">';
                    echo 'Error : '.$e['args'][1].'<br/>';
                    echo 'File : '.$f.'<br/>';
                    echo 'Line : '.$e['args'][3].'</div>';
                }
                continue;
            }

            
            $caller = "";
            if( isset($e['class']) ) 
                $caller .= $e['class'].( $e['type'] ?? '::');
            if( isset($e['function']) ) {
                $caller .= $e['function'];
                if( !isset($e['args']) ) $caller .= '()';
                else {
                    $caller .= '(';
                    $tmp = [];
                    foreach( $e['args'] as $key => $value ) {
                        $tmp[] = gettype($value);
                    }
                    $caller .= implode(', ',$tmp);
                    $caller .= ')';
                }
            }

            $style = '';
            if( $padding == 0 ) 
                $style = 'style="color:red"';


            echo '<div style="padding-left:'.$padding.'px; margin:15px 0;">';
            echo '<strong '.$style.'>'.$caller.'</strong><br/>';
            echo '<span style="padding-left:8px">└ <em> called : '.$filePath.' (line : '.$e['line'].')</em></span><br/>';
            echo '</div>';
            $padding += "40";

            
            if( empty($first) ) {
                $first = [
                    "file" => $filePath,
                    "line" => $e['line']
                ];
            }

            
        }
        echo '</pre></div>';

        if( empty($first) ) return;

        echo '<h4>'.pathinfo($first['file'])['basename'].'</h4>';
        $file = file($first['file']);
        echo '<ul class="file-reader">';
        foreach( $file as $k=>$e) {
            $nb = $k+1;
            if( $nb - $first['line'] > 3 ) break;
            if( $first['line'] - $nb > 3 ) continue;
            $ct = htmlentities($e);
            $ct = str_replace(" ","&nbsp;",$ct);
            echo '<li class="'.($nb == $first['line']?'s':'').'">'.$ct.' <span class="n">'.$nb.'</span></li>';
        }
        echo '</ul>';


        //print_r($debug);
    }
}