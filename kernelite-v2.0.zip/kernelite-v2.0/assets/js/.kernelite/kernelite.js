const kernelite = {};
const kJS = kernelite;

// Appel API
kernelite.finally = null;
kernelite.api = function call( route, params = {} ) {
    return new Promise( (resolve,reject) => {
        let destination = URL+k.cleanUrl('api/'+route)
        fetch( destination,{
            method : 'POST',
            headers: { 'Content-Type' : 'application/json;charset=UTF-8' },
            body : JSON.stringify( params ),       
        })
        .then( r => r.json() )
        .then( response => {
            if( !response?.success ) {
                kernelite.dismiss();
                kernelite.internalApiError(response?.errorMessage).then( () => {
                    reject();
                })
                return;
            }
            kernelite.hideLoader();
            resolve(response)
        })
        .catch( err => {
            loader({hide : true})
            console.dir(err)
            kernelite.modal.error("Erreur serveur");
            kernelite.dismiss();
            reject()
        })
    });
}
kernelite.cleanUrl = url => {
    return url.replace('//','/')
}

kernelite.internalApiError = ( (msg ) => {
    return new Promise( resolve => {
        kernelite.hideLoader();
        kernelite.modal.fire({
            icon: 'error',
            width : '70%',
            //title: 'Une erreur est survenue',
            html: msg == "" ?  "Aucun message d'erreur" : msg,
            confirmButtonText : 'Fermer'
        }).then( () => resolve())
    })
});



// Modals - Documentation : https://sweetalert2.github.io/#examples
kernelite.modal = Swal;
kernelite.modal.success = ( (msg = {}) => {
    kernelite.hideLoader();
    kernelite.modal.fire({
        icon : 'success',
        text: msg
      })    
})
kernelite.modal.error = ( (msg = {}) => {
    kernelite.hideLoader();
    kernelite.modal.fire({
        icon : 'error',
        html: msg
      })    
})

kernelite.modal.confirm = ( params => {
    return new Promise( (resolve,reject) => {
        kernelite.modal.fire({
            title: params?.title ?? "Confirmation",
            html : params?.text ?? null,
            showDenyButton: true,
            target : 'body',
            confirmButtonText: params?.confirmButtonText ?? "Ok",
            denyButtonText: params?.denyButtonText ?? "Annuler",
          }).then( r => {
            if (r.isConfirmed) resolve();
            reject()
          })        
    })
})
kernelite.modal.prompt = ( title, text, preval = "" ) => {
    return new Promise( async (resolve,reject) => {
        let { value: name } = await Swal.fire({
            title: title,
            input: 'text',
            inputLabel: text,
            inputValue: preval,
            showCancelButton: true
          })    
          name ? resolve(name) : reject();
    })
}
kernelite.successReload = message => {
    kernelite.dismiss();
    kernelite.modal.fire(message, '', 'success').then(()=>{
        kernelite.reload();
    })    
}
kernelite.errorReload = message => {
    kernelite.modal.fire(message, '', 'error').then(()=>{
        kernelite.reload();
    })    
}

// Notifications - Documentation @ https://github.com/caroso1222/notyf
kernelite.notyf = new Notyf({
    duration: 3000,
    types: [
        {
          type: 'warning',
          background: 'linear-gradient(45deg, rgb(239, 253, 33), rgb(255, 0, 0))',
          color : 'white',
          icon: {
            className: 'fa-solid fa-gear rotate',
            tagName: 'i',
            text: '',
            color : 'white'
          }
        }
      ]    
});
kernelite.success = ( (msg,dismissAll = true)  => {
    if( dismissAll ) kernelite.notyf.dismissAll();
    kernelite.notyf.success(msg) 
    return this;
});
kernelite.error = ( (msg,dismissAll = true) => {
    if( dismissAll ) kernelite.notyf.dismissAll();
    kernelite.notyf.error(msg) 
    return this;
});
kernelite.dismiss = () => kernelite.notyf.dismissAll();
kernelite.progress = ( (msg,dismissible = false) => {
    kernelite.notyf.open({
        type: 'warning',
        message: msg,
        dismissible : dismissible,
        duration : 0
    });
    return this;
})
kernelite.loading = ( title = "", msg = "" ) => {
	k.modal.fire({
		title: ( title == "" ? 'Veuillez patienter...' : title ),
        html : msg,
		allowEscapeKey: false,
		allowOutsideClick: false,
		showConfirmButton : false,
		showCancelButton : false
	})
}




// Dates
kernelite.date = {
    getTimestamp : ( str = false ) => str ? Date.parse(str) : Date.now(),
    get : ( format = false, full = false, $value = false ) => {
        let date = $value ? new Date($value) : new Date(),
            year = date.getFullYear(),
            month = date.getMonth() + 1,
            day = date.getDate(),
            hours = date.getHours(),
            min = date.getMinutes(),
            sec = date.getSeconds();
        if( day < 10 ) day = "0"+day
        if( month < 10 ) month = "0"+month
        if( hours < 10 ) hours = "0"+hours
        if( min < 10 ) min = "0"+min
        if( sec < 10 ) sec = "0"+sec
        if( !full ) 
            return format ? [day,month,year].join('/') : [year,month,day].join('-');
        if( format )
            return [day,month,year].join('/') + ' ' + hours + "h" + min + "min" + sec;
        return [year,month,day].join('-') + ' ' + [hours,min,sec].join(':');        
    }
}


// Events
kernelite.events = {
    datepicker : () => {
        $(".kernel-datepicker").each(function(){
            $(this).datepicker();
        })
    }
}
kernelite.fireEvent = (eventName) => {
    if( kernelite.events.hasOwnProperty(eventName) )
        kernelite.events[eventName]();
    else
        kernelite.error("Event introuvable : "+eventName)
}

// Login
kernelite.login = ( datas => {
    return new Promise( (resolve,reject) => {
        fetch( URL,{
            method : 'POST',
            body : JSON.stringify(datas),       
        })
        .then( r => r.json() )
        .then( response => {
            if( !response?.success ) return kernelite.modal.error(response?.errorMessage);
            if( !response?.login ) reject();
            if( response?.login === true )resolve();
        })
        .catch( err => {
            console.dir(err)
            reject();
        })
    })
})


// Checks
kernelite.isNull = ( value => {
    if( typeof value == "string" && value.trim() == "" ) return true;
    else if( typeof value == "integer" && parseInt(value) == 0 ) return true;
    else if( typeof value == "float" && parseFloat(value) == 0 ) return true;
    else if( value === undefined || typeof value == "undefined" || value === null ) return true;
    return false;
});
kernelite.length = ( o => {
    return (typeof o == "object"  ? Object.keys(o).length : o.length );
})


// Tools
kernelite.reload = () => window.location.reload()
kernelite.refresh = () => kernelite.reload()
kernelite.getURL = () => window.location.href;
kernelite.inURL = (needle) => kernelite.getURL().indexOf(needle) > 0

// Files
kernelite.upload = function(props = {}) {
    return new Promise( (resolve,reject) => {
        kernelite.generateInputFile(props).then( o => {
            let fd = new FormData();   
            let files = [];
            for( let i in o.files ) {
                if( typeof o.files[i] != "object" ) continue;
                if( props?.size && o.files[i].size > props.size ) {
                    kernelite.modal.error("Le fichier est trop lourd<br/>Limite de poids : "+kernelite.humanFileSize(props.size));
                    reject()
                    return;
                }
                if( props?.formats && props?.formats?.length > 0 ) {
                    let name = o.files[i].name;
                    let tmp = name.split(".");
                    let ext = tmp.pop().toLowerCase();
                    if( !props.formats.includes(ext) ) {
                        kernelite.modal.error("Ce type de fichier (."+ext+") n'est pas autorisé<br/>Autorisés : "+props.formats.join(', '));
                        reject();
                        return;
                    }
                }
                fd.append('kerneliteUpload[]', o.files[i]);
            }
            kernelite.progress( props.progressMessage ?? 'Chargement...' )
            fetch(URL+'kernelite/asyncFileUpload',{
                method : 'POST',
                body : fd
            })
            .then( r => r.json() )
            .then( response => {
                setTimeout( () => k.dismiss(), 500 )
                if( !response?.success ) {
                    kernelite.internalApiError(response?.errorMessage)
                    return false;
                }    
                resolve(response);  
            })
        }); 
    })
};
kernelite.generateInputFile = (props) => {
    return new Promise( resolve => {
        let name = '_kerneliteTmpFile';
        if( $("#"+name).length ) $("#"+name).remove();
        $('body').append('<input type="file" id="'+name+'" style="display:none"/>');       
        let el = $("#"+name);
        if( props?.multiple ) el.prop('multiple',true);
        if( props?.accept ) el.attr('accept', props.accept );
        el.trigger('click').on('change', function() {
            resolve({
                obj : $(this)[0],
                files : $(this)[0].files
            });
        });
    })
}
kernelite.humanFileSize = (bytes, si=false, dp=1) => {
    const thresh = si ? 1000 : 1024;
    if (Math.abs(bytes) < thresh) 
      return bytes + ' B';
    const units = si 
      ? ['kB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'] 
      : ['KiB', 'MiB', 'GiB', 'TiB', 'PiB', 'EiB', 'ZiB', 'YiB'];
    let u = -1;
    const r = 10**dp;

    do {
      bytes /= thresh;
      ++u;
    } while (Math.round(Math.abs(bytes) * r) / r >= thresh && u < units.length - 1);
    return bytes.toFixed(dp) + ' ' + units[u];
}
kernelite.removeTmp = ( tmp => {
    return new Promise( (resolve,reject) => {
        fetch(URL+'kernelite/removeTmpDir',{
            method : 'POST',
            body : JSON.stringify({ tmpDir : tmp })
        })
        .then( r => r.json() )
        .then( response => {
            if( !response?.success ) {
                kernelite.internalApiError(response?.errorMessage)
                reject();
            }    
            resolve(response);  
        })    
    })
})

// Conversions de types
kernelite.getForm = idForm => kernelite.formToJson( idForm ) // Alias
kernelite.formToJson = ( idForm ) => {
    let f = $("#"+idForm), obj = {};
    if( f.length == 0 ) {
        knotice("Impossible de trouver le formulaire #"+idForm);
        return obj
    }
    else {
        let Arr = f.serializeArray();
        for( let i in Arr ) {
            if( Arr[i].name.includes('[]') ) {
                let name = Arr[i].name.replace('[]','');
                if( !obj[name] ) obj[name] = [];
                obj[name].push(Arr[i].value)
            }
            else obj[Arr[i].name] = Arr[i].value
        }
    }    
    return obj;
}
kernelite.toArray = object => {
    let arr = []
    for( let i in object )
        arr.push(object[i])
    return arr;
} 
kernelite.clone = object => {
    if( typeof object != "object" ) return null;
    return JSON.parse(JSON.stringify(object))
}

// Loader
kernelite.loaderName = 'kernelite-loader-template';
kernelite.showLoader = () => {
    let k = $('body').find('#'+kernelite.loaderName);
    if( k.length && !k.is(':visible') ) k.show();
}
kernelite.hideLoader = () => {
    let k = $('body').find('#'+kernelite.loaderName);
    if( k.length && k.is(':visible') ) k.hide();
}


// Connection
kernelite.isConnected = async () => {
    const state = await fetch(URL+'kernelite/isConnected')
    .then( r => r.json() )
    .then( response => { return response.connected }) 
    return state;
}

// Navigation
kernelite.navigate = ( (path,newWindow = false) => {
    return newWindow ? 
        window.open(path.includes('http') ? path : URL+path)
        : $(location).attr('href', path.includes('http') ? path : URL+path );
})
kernelite.nav = (path,newWindow=false) => kernelite.navigate(path,newWindow)


// Params - with Cookies
kernelite.paramsKeyString  = "_kernelite_settings_";
kernelite.defaultExpireParam = 30; // 30 jours par defaut
kernelite.paramsObject = {};
kernelite.params = {
    init : () => {
        let object = Cookies.get(kernelite.paramsKeyString)
        if( !kernelite.isNull(object) ) {
            kernelite.paramsObject = JSON.parse( object );
        }
    },
    set : ( key, value ) => {
        kernelite.paramsObject[key] = value;
        kernelite.params.save();    
    },
    get : (key) => {
        return kernelite.paramsObject[key] ?? null;
    },
    reset : () => {
        kernelite.paramsObject = {};
        kernelite.params.save();        
    },
    save : () => {
        let date = new Date();
        Cookies.set( 
            kernelite.paramsKeyString, 
            JSON.stringify( kernelite.paramsObject ),
            {
                url : URL,
                expires : kernelite.defaultExpireParam
            }
        );
    }
}



// Tooltips 
kernelite.tooltips = () => {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
      return new bootstrap.Tooltip(tooltipTriggerEl,{ html : true, trigger: "hover" })
    })    
}

// Silent download
kernelite.download = (linkUrl, name = "download") => {
    let link = document.createElement("a");
    link.download = name;
    link.href = linkUrl;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    delete link; 
}


// Layer
kernelite.layer = ( params ) => {
    kernelite.modal.fire({
        template : '#kernelite-layer-template',
        html : params?.html,
        width : params?.width ?? '90%',
        confirmButtonText : params?.confirmButtonText ?? "Fermer",
        didOpen : () => {
            if( typeof params.didOpen == "function" )
                params.didOpen()
        },
        customClass: {
            container : params?.class ?? 'kernelite-layer-class'
        }
    })
}

// EasyBinds
kernelite.bindStack = [];
kernelite.bind = (obj,event,callback) => {
    kernelite.bindStack.push([obj,event,callback])
}
kernelite.binds = arr => { for( let i in arr ) kernelite.bind(arr[i]) }
kernelite.click = (obj,callback = null) => {
    if( typeof obj == "string" )
        kernelite.bind(obj,'click',callback) 
    else 
        kernelite.bind(obj[0],'click',obj[1]) 
}
kernelite.clicks = arr => { for( let i in arr ) kernelite.click(arr[i]) }
kernelite.bindStackTimeout = setTimeout(()=>{
    for( let i in kernelite.bindStack ) {
        let [obj,event,callback] = kernelite.bindStack[i]
        $(document).on(event,obj, function(event) { 
            if( typeof callback == "function")
                callback($(this), event )
            else 
                eval(callback)( $(this),event ) 
        })
    }
}, 500);
kernelite.offBind = e => $(document).off(e);




// Number format
kernelite.number_format = (number, decimals, dec_point = ",", thousands_sep = " ")  => {
    number = (number + '').replace(/[^0-9+\-Ee.]/g, '');
    let n = !isFinite(+number) ? 0 : +number,
        prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
        sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
        dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
        s = '',
        toFixedFix = function (n, prec) {
            let k = Math.pow(10, prec);
            return '' + Math.round(n * k) / k;
        };
    s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
    if (s[0].length > 3) 
        s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
    if ((s[1] || '').length < prec) {
        s[1] = s[1] || '';
        s[1] += new Array(prec - s[1].length + 1).join('0');
    }
    return s.join(dec);
}
kernelite.number_unformat = (text) => parseFloat( text.replaceAll(',','.').replaceAll(' ','') )