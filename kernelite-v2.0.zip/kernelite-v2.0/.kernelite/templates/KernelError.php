<!DOCTYPE html>
<html lang="fr">
    <head>
        <title>Erreur | <?php echo PROJECT_NAME;?></title>
        <link rel="icon" href="./assets/css/vendor/images/kernelite-logo-sm.png" type="image/png">
        <?php __kernel_load_styles();?>
        <?php __kernel_load_scripts();?>
        <style>
            .errorPage {
                box-shadow: 4px 4px 6px #aaa;
            }
            .alert h4 {
                color: #664d03;
                border-bottom: 5px solid #664d03;
                margin: 15px 0;
                line-height: 40px;
                text-align: left;
            }
            .file-reader {
                background: #263238;
                color: #fff;
                list-style-type: none;
                border: 5px solid #000;
                font-family: 'Courier New', Courier, monospace;
                padding: 10px;
            }
            .file-reader li {
                position: relative;
                padding-left: 35px;
                font-size: 13px;
                line-height: 25px;
                text-align: left;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            .file-reader li.s {
                background: #CFD8DC;
                color: #000;
            }
            .file-reader li span {
                position: absolute;
                left: 5px;
                top: 1px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-3 text-center">
                    <img src="<?php echo URL;?>assets/css/vendor/images/kernelite-logo-m.png" style="height:250px"/>
                </div>
                <div class="col">
                    <h1 style="margin-top:100px" class="text-danger">
                        &lsaquo;error&rsaquo;
                            <span style="color:#000;font-size:50px;">.kernelite</span>
                        &lsaquo;/error&rsaquo;
                    </h1>
                </div>
            </div>
            <div class="errorPage">
                <div class="text-white text-center" style="padding:20px 0;background: #D32F2F;border-bottom: 4px solid #B71C1C;">
                    <h4 style="line-height:20px; font-size:18px;margin:0;"><?php echo $errorMessage;?></h4>
                </div>

                <?php if( ENV == "DEV" ) { ?>
                <div class="alert alert-warning">

                    <?php 
                    echo '<h4>Stacktrace</h4>';
                    KernelError::printDebugTrace();

                    if(isset($Kernelite->queryParameters) && !empty($Kernelite->queryParameters) ) { 
                        echo '<br/><h4>QueryParmeters</h4>';
                        d($Kernelite->queryParameters);
                    }

                    $dmHistory = DataManager::history();
                    if( !empty($dmHistory) ) {
                        echo '<h4>DataManager</h4>';
                        d($dmHistory);
                    }

                    ?>

                </div>
                <?php } ?>
            </div>

        </div>
    </body>
</html>