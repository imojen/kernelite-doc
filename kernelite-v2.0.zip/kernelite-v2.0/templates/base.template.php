<!DOCTYPE html>
<html lang="fr">
<head>
    <title>{{ title }}</title>
    <link rel="icon" href="{{favicon}}" type="image/png">
    <?php
    __kernel_load_styles($this);
    __kernel_load_scripts($this);
    ?>
</head>

<body>
    <div id="body">
        {%CONTROLLER%}
    </div>
</body>
</html>