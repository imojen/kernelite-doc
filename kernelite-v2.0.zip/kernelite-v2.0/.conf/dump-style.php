<?php
$style = [
    "font-size:20px",
    "line-height:25px",
    "background: #FFEBEE",
    "border: 1px solid #aaa",
    "padding:0",
    "margin:10px",
    "max-height: 500px",
    "overflow:auto",
    "whote-space:pre-wrap",
    "max-width: 100%"
];
$h1Style = [
    "background:#D32F2F",
    "color:#fff",
    "text-align:left",
    "margin:0",
    "padding: 15px;",
    "line-height:25px;",
    "font-size:22px"
];
$h2Style = [
    "background:#B71C1C",
    "color: #fff",
    "text-align:center",
    "margin:0",
    "padding: 8px",
    "font-size:12px",
    "font-weight:normal",
    
];
$dumpStyle = [
    "margin: 10px auto",
    "padding: 0 20px",
    "font-family: courier, courier new, serif",
];