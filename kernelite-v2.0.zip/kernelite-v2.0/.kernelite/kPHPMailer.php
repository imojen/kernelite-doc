<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

class kPHPMailer {

    private $conf;
    private $defaultPHPMailerPath = APP_ROOT.'/vendor/phpmailer/phpmailer/src/';
    private $mail;
    
    public function __construct() {
        $this->defaultPHPMailerPath = path($this->defaultPHPMailerPath);
        $this
            ->loadPHPMailerConfiguration()
            ->requirePHPMailer()
            ->initMailObject()
            ->initDefaultConfig();
    }
    public function loadPHPMailerConfiguration() {
        global $GLOBAL_CONF;
        if( !isset($GLOBAL_CONF['conf']['PHPMailer']) ) 
            crashError("PHPMailer non définit");
        $this->conf = $GLOBAL_CONF['conf']['PHPMailer'];
        if( !file_exists($this->defaultPHPMailerPath) )
            err("Librairie PHPMailer non instalée sur le serveur");
        return $this;
    }
    public function requirePHPMailer() {
        $requires = ['Exception','PHPMailer','SMTP'];
        foreach( $requires as $reqFile ) {
            $reqPath = $this->defaultPHPMailerPath.$reqFile.'.php';
            if( !file_exists($reqPath) ) err($reqPath.'<br/>Fichier introuvable');
            require_once($reqPath);
        }
        return $this;
    }
    public function initMailObject() {
        $this->mail = new PHPMailer(true);
        return $this;
    }
    public function getSmtpDefaultParam( String $param ) {
        return 
            isset($this->conf['smtp'][$param]) && !empty($this->conf['smtp'][$param]) ? 
            $this->conf['smtp'][$param] : false;
    }
    public function initDefaultConfig() {
        $this->mail->isHTML(true);
        $this->mail->setLanguage('fr');
		$this->mail->setFrom(MAILER_SENDERMAIL,MAILER_SENDER);
		$this->mail->addReplyTo(MAILER_REPLYTOMAIL,MAILER_REPLYTO);
        if( $this->conf['debug'] == true )
            $this->mail->SMTPDebug = SMTP::DEBUG_SERVER;
        $use = $this->getSmtpDefaultParam('use');
        if( $use ) {
            $this->mail->isSMTP();
            $this->mail->Mailer = "smtp";
            $this->mail->SMTPAuth   = TRUE;
            $smtp = $this->conf['smtp'];
            $this->mail->Host = $this->getSmtpDefaultParam('host');
            if( $this->getSmtpDefaultParam('auth') == true ) {
                $this->mail->Username = $this->getSmtpDefaultParam('login');
                $this->mail->Password = $this->getSmtpDefaultParam('password');
            }
            $this->mail->Port = $this->getSmtpDefaultParam('port');
            switch( $this->getSmtpDefaultParam('secure') ) {
                case 1 :
                case 'tls' :
                    $this->mail->SMTPSecure  = 'tls';
                    break;
                case 2 :
                case 'ssl' : {
                    $this->mail->SMTPSecure  = 'ssl';
                    break;
                }
            }
        }
        return $this;
    }
    public function configureSMTP( Array $conf = [] ) {
        $this->mail->isSMTP();
        $this->mail->Mailer = "smtp";
        $this->mail->CharSet = 'utf-8';
        $this->mail->Host = $conf['host'] ?? '';
        $this->mail->Port = $conf['port'] ?? 465;
        if( isset($conf['auth']) && $conf['auth'] ) {
            $this->mail->SMTPAuth   = TRUE;
            $this->mail->Username = $conf['login'] ?? '';
            $this->mail->Password = $conf['password'] ?? '';
        }
        if( isset($conf['secure']) ) {
            switch( $conf['secure'] ) {
                case 1 :
                case 'tls' :
                    $this->mail->SMTPSecure  = 'tls';
                    break;
                case 2 :
                case 'ssl' : {
                    $this->mail->SMTPSecure  = 'ssl';
                    break;
                }
            }
        }
        return $this;
    }
    public function testSMTPConfiguration() {
        if( !$this->mail->smtpConnect() ) return false;
        $this->mail->smtpClose();
        return true;
    }

    public function cc( $mails ) {
        if( is_array($mails) )
            foreach( $mails as $mail ) $this->mail->addCC($mail);
        else 
            $this->mail->addCC($mails);
        return $this;
    }
    public function bcc( $mails ) {
        if( is_array($mails) )
            foreach( $mails as $mail ) $this->mail->addBCC($mail);
        else 
            $this->mail->addBCC($mails);
        return $this;
    }    
    public function to( $mails ) {
        if( is_array($mails) )
            foreach( $mails as $mail ) $this->mail->addAddress($mail);
        else 
            $this->mail->addAddress($mails);
        return $this;        
    }
    public function attachment( $files ) {
        if( is_array($files) )
            foreach( $files as $file ) $this->mail->addAttachment($file);
        else 
            $this->mail->addAttachment($files);
        return $this;           
    }
    public function setSubject( String $subject ) {
        $this->mail->Subject = $subject;
    }
    public function setBody( String $html ) {
        $this->mail->Body = $html;
    }
    public function setAltBody( String $text ) {
        $this->mail->AltBody = $text;
    }  
    public function send() {
        try {
            ob_start();
            $state = $this->mail->send();
            $buffer = ob_get_contents();
            ob_end_clean();
        }
        catch( Exception $e ) {
            err( $this->mail->ErrorInfo );
        }
        return  $state ? true : $this->mail->ErrorInfo;
    }      

}